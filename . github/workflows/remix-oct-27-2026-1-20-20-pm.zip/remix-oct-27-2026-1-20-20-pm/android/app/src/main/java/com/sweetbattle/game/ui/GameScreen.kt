package com.sweetbattle.game.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sweetbattle.game.ElementType
import com.sweetbattle.game.GameViewModel
import com.sweetbattle.game.Tile

@Composable
fun GameScreen(viewModel: GameViewModel) {
    val state by viewModel.uiState.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F172A),
                        Color(0xFF1E1B4B),
                        Color(0xFF0A0F1D)
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Title & Level Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Сладкая битва",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFF43F5E)
                    )
                    Text(
                        text = "Три в ряд · Уровень ${state.level}",
                        fontSize = 12.sp,
                        color = Color.LightGray
                    )
                }

                Button(
                    onClick = { viewModel.startNewGame() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Заново", fontSize = 12.sp)
                }
            }

            // HUD Stats
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatCard(title = "Счёт", value = state.score.toString(), modifier = Modifier.weight(1f))
                StatCard(title = "Ходы", value = state.movesLeft.toString(), modifier = Modifier.weight(1f), isAlert = state.movesLeft <= 5)
                StatCard(title = "Рекорд", value = state.highScore.toString(), modifier = Modifier.weight(1f))
            }

            // Quests summary
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0x331E293B)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    state.quests.forEach { quest ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(quest.title, fontSize = 10.sp, color = Color.Gray)
                            Text(
                                "${quest.current}/${quest.target}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (quest.completed) Color(0xFF10B981) else Color.White
                            )
                        }
                    }
                }
            }

            // 8x8 Board
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0x661E293B))
                    .border(1.dp, Color(0x3394A3B8), RoundedCornerShape(24.dp))
                    .padding(8.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    for (r in 0 until 8) {
                        Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                            for (c in 0 until 8) {
                                val tile = state.grid.getOrNull(r)?.getOrNull(c)
                                val isSelected = state.selectedTile?.first == r && state.selectedTile?.second == c

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                        .padding(2.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) Color(0x88F59E0B) else Color(0x22334155))
                                        .clickable { viewModel.onTileClick(r, c) }
                                        .pointerInput(Unit) {
                                            detectDragGestures { change, dragAmount ->
                                                change.consume()
                                                val (dx, dy) = dragAmount
                                                if (kotlin.math.abs(dx) > kotlin.math.abs(dy)) {
                                                    if (kotlin.math.abs(dx) > 20f) {
                                                        viewModel.onSwipe(r, c, 0, if (dx > 0) 1 else -1)
                                                    }
                                                } else {
                                                    if (kotlin.math.abs(dy) > 20f) {
                                                        viewModel.onSwipe(r, c, if (dy > 0) 1 else -1, 0)
                                                    }
                                                }
                                            }
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (tile != null) {
                                        CandyDrawing(type = tile.type)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Boosters
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                BoosterButton(
                    name = "Молоток",
                    count = state.hammerCount,
                    isActive = state.activeBooster == "hammer",
                    onClick = { viewModel.selectBooster("hammer") },
                    modifier = Modifier.weight(1f)
                )
                BoosterButton(
                    name = "Молния",
                    count = state.lightningCount,
                    isActive = state.activeBooster == "lightning",
                    onClick = { viewModel.selectBooster("lightning") },
                    modifier = Modifier.weight(1f)
                )
                BoosterButton(
                    name = "Перемешать",
                    count = state.shuffleCount,
                    isActive = false,
                    onClick = { viewModel.selectBooster("shuffle") },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier, isAlert: Boolean = false) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = if (isAlert) Color(0x66991B1B) else Color(0x441E293B)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, fontSize = 10.sp, color = Color.LightGray)
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Black, color = if (isAlert) Color(0xFFFCA5A5) else Color.White)
        }
    }
}

@Composable
fun BoosterButton(name: String, count: Int, isActive: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(
        onClick = onClick,
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isActive) Color(0xFFEAB308) else Color(0xFF334155)
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(name, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text("($count)", fontSize = 10.sp)
        }
    }
}

@Composable
fun CandyDrawing(type: ElementType) {
    Canvas(modifier = Modifier.fillMaxSize().padding(4.dp)) {
        val w = size.width
        val h = size.height
        when (type) {
            ElementType.HEART -> {
                val path = Path().apply {
                    moveTo(w * 0.5f, h * 0.85f)
                    cubicTo(w * 0.1f, h * 0.6f, w * 0.1f, h * 0.25f, w * 0.35f, h * 0.25f)
                    cubicTo(w * 0.5f, h * 0.25f, w * 0.5f, h * 0.4f, w * 0.5f, h * 0.4f)
                    cubicTo(w * 0.5f, h * 0.4f, w * 0.5f, h * 0.25f, w * 0.65f, h * 0.25f)
                    cubicTo(w * 0.9f, h * 0.25f, w * 0.9f, h * 0.6f, w * 0.5f, h * 0.85f)
                    close()
                }
                drawPath(path, Color(0xFFEF4444))
            }
            ElementType.STAR -> {
                drawCircle(Color(0xFF3B82F6), radius = w * 0.4f)
            }
            ElementType.CRYSTAL -> {
                val path = Path().apply {
                    moveTo(w * 0.5f, h * 0.1f)
                    lineTo(w * 0.85f, h * 0.35f)
                    lineTo(w * 0.85f, h * 0.65f)
                    lineTo(w * 0.5f, h * 0.9f)
                    lineTo(w * 0.15f, h * 0.65f)
                    lineTo(w * 0.15f, h * 0.35f)
                    close()
                }
                drawPath(path, Color(0xFF10B981))
            }
            ElementType.LIGHTNING -> {
                val path = Path().apply {
                    moveTo(w * 0.55f, h * 0.1f)
                    lineTo(w * 0.2f, h * 0.55f)
                    lineTo(w * 0.45f, h * 0.55f)
                    lineTo(w * 0.35f, h * 0.9f)
                    lineTo(w * 0.8f, h * 0.45f)
                    lineTo(w * 0.55f, h * 0.45f)
                    close()
                }
                drawPath(path, Color(0xFFFBBF24))
            }
            ElementType.CIRCLE -> {
                drawCircle(Color(0xFFA855F7), radius = w * 0.4f)
            }
            ElementType.DROP -> {
                val path = Path().apply {
                    moveTo(w * 0.5f, h * 0.15f)
                    cubicTo(w * 0.2f, h * 0.5f, w * 0.2f, h * 0.85f, w * 0.5f, h * 0.85f)
                    cubicTo(w * 0.8f, h * 0.85f, w * 0.8f, h * 0.5f, w * 0.5f, h * 0.15f)
                    close()
                }
                drawPath(path, Color(0xFFF97316))
            }
        }
    }
}
