package com.sweetbattle.game

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.random.Random

enum class ElementType {
    HEART,     // Красное сердце
    STAR,      // Синяя звезда
    CRYSTAL,   // Зелёный кристалл
    LIGHTNING, // Жёлтая молния
    CIRCLE,    // Фиолетовый круг
    DROP       // Оранжевая капля
}

data class Tile(
    val id: Long,
    val type: ElementType,
    val row: Int,
    val col: Int,
    val isMatched: Boolean = false
)

data class Quest(
    val id: String,
    val title: String,
    val current: Int,
    val target: Int,
    val completed: Boolean = false,
    val reward: String
)

data class GameUiState(
    val grid: List<List<Tile?>> = List(8) { List(8) { null } },
    val score: Int = 0,
    val level: Int = 1,
    val movesLeft: Int = 30,
    val highScore: Int = 0,
    val selectedTile: Pair<Int, Int>? = null,
    val activeBooster: String? = null,
    val hammerCount: Int = 3,
    val lightningCount: Int = 2,
    val shuffleCount: Int = 2,
    val quests: List<Quest> = emptyList(),
    val isProcessing: Boolean = false,
    val isGameOver: Boolean = false,
    val dailyRewardAvailable: Boolean = true,
    val dailyRewardClaimedToday: String? = null,
    val dailyStreak: Int = 1
)

class GameViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(GameUiState())
    val uiState = _uiState.asStateFlow()

    private var tileIdSeq = 1L

    init {
        startNewGame()
        checkDailyReward()
    }

    private fun checkDailyReward() {
        // Проверка даты последнего захода (SharedPreferences)
        // Если дата != текущей, dailyRewardAvailable = true
    }

    fun claimDailyReward(rewardType: String) {
        val current = _uiState.value
        when (rewardType) {
            "hammer" -> _uiState.value = current.copy(
                hammerCount = current.hammerCount + 1,
                dailyRewardAvailable = false,
                dailyRewardClaimedToday = "hammer"
            )
            "lightning" -> _uiState.value = current.copy(
                lightningCount = current.lightningCount + 1,
                dailyRewardAvailable = false,
                dailyRewardClaimedToday = "lightning"
            )
            "shuffle" -> _uiState.value = current.copy(
                shuffleCount = current.shuffleCount + 1,
                dailyRewardAvailable = false,
                dailyRewardClaimedToday = "shuffle"
            )
        }
    }

    fun startNewGame() {
        tileIdSeq = 1L
        val initialGrid = generateInitialBoard()
        val initialQuests = listOf(
            Quest("q1", "Набрать 100 очков", 0, 100, false, "+3 хода"),
            Quest("q2", "Собрать 10 сердец", 0, 10, false, "+1 молоток"),
            Quest("q3", "Комбинация из 4", 0, 1, false, "+1 молния")
        )

        _uiState.value = GameUiState(
            grid = initialGrid,
            score = 0,
            level = 1,
            movesLeft = 30,
            highScore = _uiState.value.highScore,
            quests = initialQuests
        )
    }

    private fun generateInitialBoard(): List<List<Tile?>> {
        val board = MutableList(8) { r ->
            MutableList<Tile?>(8) { c -> null }
        }

        for (r in 0 until 8) {
            for (c in 0 until 8) {
                val exclude = mutableListOf<ElementType>()
                if (c >= 2 && board[r][c - 1]?.type == board[r][c - 2]?.type) {
                    board[r][c - 1]?.type?.let { exclude.add(it) }
                }
                if (r >= 2 && board[r - 1][c]?.type == board[r - 2][c]?.type) {
                    board[r - 1][c]?.type?.let { exclude.add(it) }
                }

                val available = ElementType.values().filterNot { it in exclude }
                val type = available[Random.nextInt(available.size)]
                board[r][c] = Tile(tileIdSeq++, type, r, c)
            }
        }
        return board
    }

    fun onTileClick(row: Int, col: Int) {
        val state = _uiState.value
        if (state.isProcessing || state.isGameOver) return

        // Handle Active Booster
        if (state.activeBooster != null) {
            applyBoosterAt(state.activeBooster, row, col)
            return
        }

        val selected = state.selectedTile
        if (selected == null) {
            _uiState.value = state.copy(selectedTile = Pair(row, col))
        } else {
            if (selected.first == row && selected.second == col) {
                _uiState.value = state.copy(selectedTile = null)
            } else if (isAdjacent(selected.first, selected.second, row, col)) {
                _uiState.value = state.copy(selectedTile = null)
                swapAndResolve(selected.first, selected.second, row, col)
            } else {
                _uiState.value = state.copy(selectedTile = Pair(row, col))
            }
        }
    }

    fun onSwipe(r: Int, c: Int, dr: Int, dc: Int) {
        val state = _uiState.value
        if (state.isProcessing || state.isGameOver) return
        val targetR = r + dr
        val targetC = c + dc
        if (targetR in 0..7 && targetC in 0..7) {
            swapAndResolve(r, c, targetR, targetC)
        }
    }

    private fun isAdjacent(r1: Int, c1: Int, r2: Int, c2: Int): Boolean {
        return (abs(r1 - r2) == 1 && c1 == c2) || (abs(c1 - c2) == 1 && r1 == r2)
    }

    private fun swapAndResolve(r1: Int, c1: Int, r2: Int, c2: Int) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isProcessing = true)

            // Perform swap
            val currentGrid = _uiState.value.grid.map { it.toMutableList() }
            val t1 = currentGrid[r1][c1]
            val t2 = currentGrid[r2][c2]

            currentGrid[r1][c1] = t2?.copy(row = r1, col = c1)
            currentGrid[r2][c2] = t1?.copy(row = r2, col = c2)
            _uiState.value = _uiState.value.copy(grid = currentGrid)
            delay(150)

            val matches = findMatches(currentGrid)
            if (matches.isEmpty()) {
                // Revert swap
                currentGrid[r1][c1] = t1
                currentGrid[r2][c2] = t2
                _uiState.value = _uiState.value.copy(grid = currentGrid, isProcessing = false)
            } else {
                // Valid move: consume move and run cascade
                val movesAfter = _uiState.value.movesLeft - 1
                _uiState.value = _uiState.value.copy(movesLeft = movesAfter)
                processCascade(currentGrid)

                if (movesAfter <= 0) {
                    _uiState.value = _uiState.value.copy(isGameOver = true)
                }
            }
        }
    }

    private suspend fun processCascade(grid: List<MutableList<Tile?>>) {
        var combo = 1
        var matches = findMatches(grid)

        while (matches.isNotEmpty()) {
            // Calculate score for matches: 3=10pts, 4=25pts, 5+=50pts
            var points = 0
            var redHeartsCount = 0
            var hasCombo4 = false

            for (group in matches) {
                if (group.size == 3) points += 10
                else if (group.size == 4) { points += 25; hasCombo4 = true }
                else if (group.size >= 5) { points += 50; hasCombo4 = true }

                for (pos in group) {
                    val tile = grid[pos.first][pos.second]
                    if (tile?.type == ElementType.HEART) {
                        redHeartsCount++
                    }
                    grid[pos.first][pos.second] = null
                }
            }

            points = (points * (1 + (combo - 1) * 0.5)).toInt()
            val newScore = _uiState.value.score + points
            val newHigh = maxOf(newScore, _uiState.value.highScore)
            val newLevel = 1 + (newScore / 500)

            // Update Quests
            val updatedQuests = _uiState.value.quests.map { q ->
                when (q.id) {
                    "q1" -> q.copy(current = minOf(q.target, newScore), completed = newScore >= q.target)
                    "q2" -> q.copy(current = minOf(q.target, q.current + redHeartsCount), completed = (q.current + redHeartsCount) >= q.target)
                    "q3" -> if (hasCombo4) q.copy(current = 1, completed = true) else q
                    else -> q
                }
            }

            _uiState.value = _uiState.value.copy(
                score = newScore,
                highScore = newHigh,
                level = newLevel,
                quests = updatedQuests,
                grid = grid.map { it.toList() }
            )
            delay(200)

            // Gravity drop
            for (c in 0 until 8) {
                var writeR = 7
                for (r in 7 downTo 0) {
                    if (grid[r][c] != null) {
                        val tile = grid[r][c]!!
                        grid[r][c] = null
                        grid[writeR][c] = tile.copy(row = writeR, col = c)
                        writeR--
                    }
                }
                // Fill top
                while (writeR >= 0) {
                    val type = ElementType.values()[Random.nextInt(ElementType.values().size)]
                    grid[writeR][c] = Tile(tileIdSeq++, type, writeR, c)
                    writeR--
                }
            }

            _uiState.value = _uiState.value.copy(grid = grid.map { it.toList() })
            delay(200)

            combo++
            matches = findMatches(grid)
        }

        _uiState.value = _uiState.value.copy(isProcessing = false)
    }

    private fun findMatches(grid: List<List<Tile?>>): List<List<Pair<Int, Int>>> {
        val matchedGroups = mutableListOf<List<Pair<Int, Int>>>()

        // Horizontal
        for (r in 0 until 8) {
            var c = 0
            while (c < 8) {
                val tile = grid[r][c] ?: run { c++; return@run }
                var end = c + 1
                while (end < 8 && grid[r][end]?.type == tile.type) end++
                if (end - c >= 3) {
                    matchedGroups.add((c until end).map { Pair(r, it) })
                }
                c = end
            }
        }

        // Vertical
        for (c in 0 until 8) {
            var r = 0
            while (r < 8) {
                val tile = grid[r][c] ?: run { r++; return@run }
                var end = r + 1
                while (end < 8 && grid[end][c]?.type == tile.type) end++
                if (end - r >= 3) {
                    matchedGroups.add((r until end).map { Pair(it, c) })
                }
                r = end
            }
        }

        return matchedGroups
    }

    fun selectBooster(type: String) {
        val state = _uiState.value
        if (type == "shuffle") {
            // Instant execution
            if (state.shuffleCount > 0) {
                _uiState.value = state.copy(
                    shuffleCount = state.shuffleCount - 1,
                    grid = generateInitialBoard()
                )
            }
        } else {
            _uiState.value = state.copy(activeBooster = type)
        }
    }

    fun cancelBooster() {
        _uiState.value = _uiState.value.copy(activeBooster = null)
    }

    private fun applyBoosterAt(booster: String, r: Int, c: Int) {
        val state = _uiState.value
        val grid = state.grid.map { it.toMutableList() }

        when (booster) {
            "hammer" -> {
                if (state.hammerCount > 0) {
                    grid[r][c] = null
                    _uiState.value = state.copy(
                        hammerCount = state.hammerCount - 1,
                        activeBooster = null
                    )
                    viewModelScope.launch {
                        processCascade(grid)
                    }
                }
            }
            "lightning" -> {
                if (state.lightningCount > 0) {
                    for (col in 0 until 8) {
                        grid[r][col] = null
                    }
                    _uiState.value = state.copy(
                        lightningCount = state.lightningCount - 1,
                        activeBooster = null
                    )
                    viewModelScope.launch {
                        processCascade(grid)
                    }
                }
            }
        }
    }
}
