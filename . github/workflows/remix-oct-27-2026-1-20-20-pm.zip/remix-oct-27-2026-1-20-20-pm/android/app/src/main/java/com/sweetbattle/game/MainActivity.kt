package com.sweetbattle.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.sweetbattle.game.ui.GameScreen
import com.sweetbattle.game.ui.theme.SweetBattleTheme

class MainActivity : ComponentActivity() {
    private val viewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        // Нативный сплэш-экран Android (Splash Screen API)
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SweetBattleTheme {
                GameScreen(viewModel = viewModel)
            }
        }
    }
}
