/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ElementType } from '../types/game';

interface CandyIconProps {
  type: ElementType;
  className?: string;
  isMatched?: boolean;
  isSpecial?: boolean;
}

export const CandyIcon: React.FC<CandyIconProps> = ({
  type,
  className = 'w-full h-full',
  isMatched = false,
}) => {
  return (
    <div
      className={`relative flex items-center justify-center transition-transform duration-150 ${className} ${
        isMatched ? 'scale-125 opacity-0' : 'scale-100'
      }`}
    >
      {type === 'heart' && (
        // Красное сердце
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow-[0_4px_10px_rgba(239,68,68,0.5)]">
          <defs>
            <radialGradient id="heartGrad" cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#fca5a5" />
              <stop offset="25%" stopColor="#ef4444" />
              <stop offset="75%" stopColor="#b91c1c" />
              <stop offset="100%" stopColor="#7f1d1d" />
            </radialGradient>
            <linearGradient id="heartGloss" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
            </linearGradient>
            <filter id="heartGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#ef4444" floodOpacity="0.6" />
            </filter>
          </defs>
          {/* Main 3D heart */}
          <path
            d="M32 54 C32 54 8 38 8 22 C8 12.5 15.5 6 24 6 C28.5 6 31 9 32 11 C33 9 35.5 6 40 6 C48.5 6 56 12.5 56 22 C56 38 32 54 32 54 Z"
            fill="url(#heartGrad)"
            filter="url(#heartGlow)"
          />
          {/* Top gloss curve */}
          <path
            d="M14 18 C14 11 19 8 24 8 C27 8 29.5 9.5 31 11.5 C27 10 20 12 16 19 C14.8 21.2 14.2 24 14 26 C13.9 22 13.9 19.5 14 18 Z"
            fill="url(#heartGloss)"
          />
          {/* Specular spot */}
          <ellipse cx="22" cy="15" rx="4" ry="2" transform="rotate(-25 22 15)" fill="#ffffff" opacity="0.75" />
        </svg>
      )}

      {type === 'star' && (
        // Синяя звезда
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow-[0_4px_10px_rgba(59,130,246,0.55)]">
          <defs>
            <radialGradient id="starGrad" cx="40%" cy="35%" r="65%">
              <stop offset="0%" stopColor="#93c5fd" />
              <stop offset="30%" stopColor="#3b82f6" />
              <stop offset="70%" stopColor="#1d4ed8" />
              <stop offset="100%" stopColor="#1e3a8a" />
            </radialGradient>
            <linearGradient id="starGloss" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.9" />
              <stop offset="60%" stopColor="#ffffff" stopOpacity="0.1" />
            </linearGradient>
            <filter id="starGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="2" stdDeviation="3.5" floodColor="#3b82f6" floodOpacity="0.7" />
            </filter>
          </defs>
          {/* 3D 5-pointed star */}
          <polygon
            points="32,6 39.5,23.5 58,24.5 43.5,36.5 48.5,54.5 32,44 15.5,54.5 20.5,36.5 6,24.5 24.5,23.5"
            fill="url(#starGrad)"
            filter="url(#starGlow)"
          />
          {/* Facet bevel highlights */}
          <polygon points="32,6 39.5,23.5 32,44" fill="#60a5fa" opacity="0.4" />
          <polygon points="32,6 24.5,23.5 32,44" fill="#ffffff" opacity="0.3" />
          {/* Central jewel shine */}
          <circle cx="32" cy="30" r="5" fill="#ffffff" opacity="0.6" filter="blur(1px)" />
        </svg>
      )}

      {type === 'crystal' && (
        // Зелёный кристалл
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow-[0_4px_10px_rgba(34,197,94,0.55)]">
          <defs>
            <linearGradient id="crystMain" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#86efac" />
              <stop offset="35%" stopColor="#22c55e" />
              <stop offset="75%" stopColor="#15803d" />
              <stop offset="100%" stopColor="#14532d" />
            </linearGradient>
            <linearGradient id="crystFacetL" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0.7" />
              <stop offset="100%" stopColor="#4ade80" stopOpacity="0.2" />
            </linearGradient>
            <filter id="crystGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#22c55e" floodOpacity="0.65" />
            </filter>
          </defs>
          {/* Hexagonal diamond crystal */}
          <polygon
            points="32,6 52,19 52,45 32,58 12,45 12,19"
            fill="url(#crystMain)"
            filter="url(#crystGlow)"
          />
          {/* Top table facet */}
          <polygon points="32,15 44,23 32,32 20,23" fill="#86efac" opacity="0.6" />
          {/* Left top facet */}
          <polygon points="32,6 52,19 44,23 32,15" fill="url(#crystFacetL)" />
          {/* Bottom left facet */}
          <polygon points="20,23 32,32 32,58 12,45 12,19" fill="#ffffff" opacity="0.25" />
          {/* Specular sparkle */}
          <polygon points="32,6 36,16 32,20 28,16" fill="#ffffff" opacity="0.75" />
        </svg>
      )}

      {type === 'lightning' && (
        // Жёлтая молния
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow-[0_4px_10px_rgba(234,179,8,0.65)]">
          <defs>
            <linearGradient id="boltGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#fef08a" />
              <stop offset="30%" stopColor="#eab308" />
              <stop offset="75%" stopColor="#ca8a04" />
              <stop offset="100%" stopColor="#854d0e" />
            </linearGradient>
            <filter id="boltGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="2" stdDeviation="3.5" floodColor="#eab308" floodOpacity="0.8" />
            </filter>
          </defs>
          {/* 3D dynamic lightning */}
          <polygon
            points="36,6 14,33 28,33 22,58 48,27 34,27"
            fill="url(#boltGrad)"
            filter="url(#boltGlow)"
          />
          {/* Inner core glow beam */}
          <polygon points="35,11 19,32 29,32 25,50 43,28 33,28" fill="#fef9c3" opacity="0.7" />
          {/* Gloss spark */}
          <line x1="33" y1="9" x2="26" y2="28" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" opacity="0.85" />
        </svg>
      )}

      {type === 'circle' && (
        // Фиолетовый круг / сфера
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow-[0_4px_10px_rgba(168,85,247,0.6)]">
          <defs>
            <radialGradient id="orbGrad" cx="35%" cy="30%" r="70%">
              <stop offset="0%" stopColor="#f3e8ff" />
              <stop offset="25%" stopColor="#d8b4fe" />
              <stop offset="55%" stopColor="#a855f7" />
              <stop offset="85%" stopColor="#7e22ce" />
              <stop offset="100%" stopColor="#581c87" />
            </radialGradient>
            <filter id="orbGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#a855f7" floodOpacity="0.7" />
            </filter>
          </defs>
          {/* Glass orb body */}
          <circle cx="32" cy="32" r="24" fill="url(#orbGrad)" filter="url(#orbGlow)" />
          {/* Cosmic ring / aura */}
          <ellipse cx="32" cy="32" rx="22" ry="7" transform="rotate(-25 32 32)" fill="none" stroke="#e9d5ff" strokeWidth="2.5" opacity="0.65" strokeDasharray="3 2" />
          {/* Specular gloss highlight */}
          <ellipse cx="25" cy="22" rx="7" ry="4" transform="rotate(-30 25 22)" fill="#ffffff" opacity="0.85" />
          <circle cx="21" cy="18" r="2" fill="#ffffff" opacity="0.9" />
        </svg>
      )}

      {type === 'drop' && (
        // Оранжевая капля
        <svg viewBox="0 0 64 64" className="w-full h-full drop-shadow-[0_4px_10px_rgba(249,115,22,0.6)]">
          <defs>
            <radialGradient id="dropGrad" cx="35%" cy="40%" r="65%">
              <stop offset="0%" stopColor="#ffedd5" />
              <stop offset="25%" stopColor="#fb923c" />
              <stop offset="70%" stopColor="#ea580c" />
              <stop offset="100%" stopColor="#9a3412" />
            </radialGradient>
            <filter id="dropGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#ea580c" floodOpacity="0.7" />
            </filter>
          </defs>
          {/* Volumetric droplet */}
          <path
            d="M32 8 C32 8 14 26 14 38 C14 48 22 56 32 56 C42 56 50 48 50 38 C50 26 32 8 32 8 Z"
            fill="url(#dropGrad)"
            filter="url(#dropGlow)"
          />
          {/* Curved liquid gloss meniscus */}
          <path
            d="M20 36 C20 28 28 17 31 13 C31 13 22 24 22 36 C22 41 24 45 27 48 C22 46 20 41 20 36 Z"
            fill="#ffffff"
            opacity="0.75"
          />
          {/* Round refraction highlight */}
          <ellipse cx="24" cy="38" rx="4" ry="7" transform="rotate(-15 24 38)" fill="#ffffff" opacity="0.8" />
        </svg>
      )}
    </div>
  );
};
