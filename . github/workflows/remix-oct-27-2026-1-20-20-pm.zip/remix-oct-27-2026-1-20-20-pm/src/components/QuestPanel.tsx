/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Quest } from '../types/game';
import { CheckCircle2, Gift, Sparkles, Target } from 'lucide-react';
import { CandyIcon } from './CandyIcon';

interface QuestPanelProps {
  quests: Quest[];
  isDark: boolean;
  onClaimNotification?: string | null;
}

export const QuestPanel: React.FC<QuestPanelProps> = ({ quests, isDark, onClaimNotification }) => {
  return (
    <div
      className={`relative w-full rounded-2xl p-3 sm:p-4 backdrop-blur-xl transition-all duration-300 border ${
        isDark
          ? 'bg-slate-900/60 border-slate-700/60 shadow-[0_8px_32px_rgba(0,0,0,0.4)]'
          : 'bg-white/70 border-white/60 shadow-[0_8px_32px_rgba(31,38,135,0.08)] text-slate-800'
      }`}
    >
      {/* Title bar */}
      <div className="flex items-center justify-between mb-2.5">
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400">
            <Target className="w-4 h-4" />
          </div>
          <span className="text-xs sm:text-sm font-bold tracking-wide uppercase">
            Задания уровня
          </span>
        </div>
        <span className="text-xs font-semibold text-slate-400">
          Выполнено: {quests.filter(q => q.completed).length}/{quests.length}
        </span>
      </div>

      {/* Quests list */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        {quests.map(quest => {
          const progressPercent = Math.min(100, Math.round((quest.current / quest.target) * 100));

          return (
            <div
              key={quest.id}
              className={`relative overflow-hidden rounded-xl p-2.5 flex flex-col justify-between transition-all duration-300 border ${
                quest.completed
                  ? isDark
                    ? 'bg-emerald-950/40 border-emerald-500/40 shadow-[0_0_15px_rgba(16,185,129,0.15)]'
                    : 'bg-emerald-50/90 border-emerald-300 shadow-sm'
                  : isDark
                  ? 'bg-slate-800/40 border-slate-700/40'
                  : 'bg-white/80 border-slate-200/80 shadow-xs'
              }`}
            >
              {/* Header row of quest */}
              <div className="flex items-start justify-between gap-1.5 mb-1.5">
                <div className="flex items-center gap-1.5 flex-1 min-w-0">
                  {quest.type === 'red_hearts' ? (
                    <div className="w-5 h-5 shrink-0">
                      <CandyIcon type="heart" />
                    </div>
                  ) : quest.type === 'score' ? (
                    <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                  ) : (
                    <div className="w-4 h-4 rounded bg-indigo-500/30 text-indigo-400 flex items-center justify-center text-[10px] font-black shrink-0">
                      4x
                    </div>
                  )}
                  <span
                    className={`text-xs font-semibold truncate ${
                      quest.completed
                        ? 'text-emerald-500 font-bold'
                        : isDark
                        ? 'text-slate-200'
                        : 'text-slate-800'
                    }`}
                  >
                    {quest.title}
                  </span>
                </div>

                {quest.completed ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 animate-bounce" />
                ) : (
                  <span className="text-[11px] font-mono font-medium text-slate-400 shrink-0 tabular-nums">
                    {quest.current}/{quest.target}
                  </span>
                )}
              </div>

              {/* Progress bar */}
              <div className="w-full h-1.5 rounded-full overflow-hidden bg-slate-700/30 mb-1.5">
                <div
                  className={`h-full transition-all duration-500 rounded-full ${
                    quest.completed
                      ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)]'
                      : 'bg-gradient-to-r from-blue-500 to-indigo-500'
                  }`}
                  style={{ width: `${progressPercent}%` }}
                />
              </div>

              {/* Reward preview */}
              <div className="flex items-center justify-between text-[10px]">
                <span className="text-slate-400">Награда:</span>
                <span
                  className={`font-semibold flex items-center gap-1 ${
                    quest.completed
                      ? 'text-emerald-400'
                      : isDark
                      ? 'text-amber-300'
                      : 'text-amber-600'
                  }`}
                >
                  <Gift className="w-3 h-3" />
                  {quest.rewardText}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Floating reward toast if claimed */}
      {onClaimNotification && (
        <div className="mt-2 text-center text-xs font-bold text-emerald-400 bg-emerald-500/20 border border-emerald-400/30 rounded-lg py-1 px-2 animate-pulse flex items-center justify-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5" />
          {onClaimNotification}
        </div>
      )}
    </div>
  );
};
