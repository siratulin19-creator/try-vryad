/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BoosterState, BoosterType } from '../types/game';
import { Hammer, Zap, Shuffle, X } from 'lucide-react';

interface BoosterBarProps {
  boosters: BoosterState;
  activeBooster: BoosterType | null;
  onSelectBooster: (type: BoosterType) => void;
  onCancelBooster: () => void;
  disabled: boolean;
  isDark: boolean;
}

export const BoosterBar: React.FC<BoosterBarProps> = ({
  boosters,
  activeBooster,
  onSelectBooster,
  onCancelBooster,
  disabled,
  isDark,
}) => {
  const boosterConfigs: {
    type: BoosterType;
    name: string;
    description: string;
    icon: React.ReactNode;
    color: string;
    borderActive: string;
    count: number;
  }[] = [
    {
      type: 'hammer',
      name: 'Молоток',
      description: 'Удаляет 1 выбранную клетку',
      icon: <Hammer className="w-5 h-5" />,
      color: 'from-amber-500 to-rose-500',
      borderActive: 'border-amber-400 ring-2 ring-amber-400/50 shadow-[0_0_15px_rgba(245,158,11,0.5)]',
      count: boosters.hammer,
    },
    {
      type: 'lightning',
      name: 'Молния',
      description: 'Уничтожает всю строку',
      icon: <Zap className="w-5 h-5" />,
      color: 'from-cyan-400 to-blue-600',
      borderActive: 'border-cyan-400 ring-2 ring-cyan-400/50 shadow-[0_0_15px_rgba(6,182,212,0.5)]',
      count: boosters.lightning,
    },
    {
      type: 'shuffle',
      name: 'Перемешать',
      description: 'Меняет местами все элементы',
      icon: <Shuffle className="w-5 h-5" />,
      color: 'from-purple-500 to-pink-500',
      borderActive: 'border-purple-400 ring-2 ring-purple-400/50 shadow-[0_0_15px_rgba(168,85,247,0.5)]',
      count: boosters.shuffle,
    },
  ];

  return (
    <div className="w-full flex flex-col items-center gap-2">
      {/* Active Booster Target Indicator / Cancellation Prompt */}
      {activeBooster && (
        <div className="w-full flex items-center justify-between px-4 py-2 rounded-xl bg-amber-500/20 border border-amber-400/50 backdrop-blur-md animate-pulse">
          <div className="flex items-center gap-2 text-xs sm:text-sm font-semibold text-amber-300">
            {activeBooster === 'hammer' && <Hammer className="w-4 h-4" />}
            {activeBooster === 'lightning' && <Zap className="w-4 h-4" />}
            {activeBooster === 'shuffle' && <Shuffle className="w-4 h-4" />}
            <span>
              {activeBooster === 'hammer' && 'Нажмите на любую клетку для удара молотком'}
              {activeBooster === 'lightning' && 'Нажмите на клетку в строке, которую хотите сжечь'}
              {activeBooster === 'shuffle' && 'Подтвердите перемешивание поля'}
            </span>
          </div>
          <button
            onClick={onCancelBooster}
            className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg bg-rose-500/30 hover:bg-rose-500/50 text-rose-200 border border-rose-400/40 transition-colors"
          >
            <X className="w-3.5 h-3.5" />
            Отмена
          </button>
        </div>
      )}

      {/* Boosters Row */}
      <div className="w-full grid grid-cols-3 gap-2.5 sm:gap-4">
        {boosterConfigs.map(item => {
          const isActive = activeBooster === item.type;
          const isUsable = item.count > 0 && !disabled;

          return (
            <button
              key={item.type}
              type="button"
              disabled={!isUsable}
              onClick={() => onSelectBooster(item.type)}
              title={`${item.name} (${item.description})`}
              className={`relative flex flex-col items-center justify-center p-2.5 sm:p-3 rounded-2xl transition-all duration-200 backdrop-blur-xl border ${
                isActive
                  ? `${item.borderActive} scale-105`
                  : isDark
                  ? 'bg-slate-900/60 border-slate-700/60 hover:border-slate-500 hover:bg-slate-800/80 shadow-md'
                  : 'bg-white/80 border-slate-200/90 hover:border-slate-300 hover:bg-white shadow-sm text-slate-800'
              } ${
                !isUsable
                  ? 'opacity-40 cursor-not-allowed grayscale'
                  : 'cursor-pointer active:scale-95'
              }`}
            >
              {/* Count badge */}
              <div
                className={`absolute -top-1.5 -right-1.5 min-w-[20px] h-5 px-1.5 flex items-center justify-center rounded-full text-[11px] font-black text-white shadow-md ${
                  item.count > 0
                    ? `bg-gradient-to-r ${item.color} shadow-[0_2px_8px_rgba(0,0,0,0.3)]`
                    : 'bg-slate-600'
                }`}
              >
                {item.count}
              </div>

              {/* Icon with gradient circle */}
              <div
                className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center text-white bg-gradient-to-br ${item.color} shadow-[0_4px_12px_rgba(0,0,0,0.25)] mb-1`}
              >
                {item.icon}
              </div>

              {/* Title */}
              <span className="text-xs font-bold truncate max-w-full">
                {item.name}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
