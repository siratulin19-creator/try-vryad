/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { GameStats } from '../types/game';
import {
  RotateCcw,
  Volume2,
  VolumeX,
  Pause,
  Play,
  HelpCircle,
  Moon,
  Sun,
  Trophy,
  Smartphone,
  Sparkles,
  Gift,
} from 'lucide-react';

interface HeaderHUDProps {
  stats: GameStats;
  isPaused: boolean;
  isMuted: boolean;
  isDark: boolean;
  isDailyRewardAvailable: boolean;
  onOpenDailyReward: () => void;
  onTogglePause: () => void;
  onToggleSound: () => void;
  onToggleTheme: () => void;
  onRestart: () => void;
  onOpenRules: () => void;
  onOpenAndroidModal: () => void;
}

export const HeaderHUD: React.FC<HeaderHUDProps> = ({
  stats,
  isPaused,
  isMuted,
  isDark,
  isDailyRewardAvailable,
  onOpenDailyReward,
  onTogglePause,
  onToggleSound,
  onToggleTheme,
  onRestart,
  onOpenRules,
  onOpenAndroidModal,
}) => {
  // Smooth animated score counter
  const [displayedScore, setDisplayedScore] = useState(stats.score);

  useEffect(() => {
    if (displayedScore === stats.score) return;

    const diff = stats.score - displayedScore;
    const step = Math.ceil(Math.abs(diff) / 10);
    const timer = setTimeout(() => {
      if (diff > 0) {
        setDisplayedScore((prev) => Math.min(prev + step, stats.score));
      } else {
        setDisplayedScore((prev) => Math.max(prev - step, stats.score));
      }
    }, 25);

    return () => clearTimeout(timer);
  }, [stats.score, displayedScore]);

  // Level progress: every 500 points raises level
  const pointsInCurrentLevel = stats.score % 500;
  const levelProgressPercent = Math.min(100, Math.round((pointsInCurrentLevel / 500) * 100));

  return (
    <header className="w-full flex flex-col gap-2.5 sm:gap-3">
      {/* Top Navbar Row */}
      <div
        className={`w-full flex items-center justify-between px-3 sm:px-5 py-2.5 rounded-2xl backdrop-blur-xl border transition-all duration-300 ${
          isDark
            ? 'bg-slate-900/70 border-slate-700/60 shadow-lg'
            : 'bg-white/80 border-slate-200/80 shadow-md text-slate-800'
        }`}
      >
        {/* Game Title with candy sparkle */}
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-rose-500 via-purple-500 to-amber-400 flex items-center justify-center shadow-md">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-black tracking-tight bg-gradient-to-r from-rose-400 via-pink-400 to-amber-300 bg-clip-text text-transparent">
              Сладкая битва
            </h1>
            <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-medium">
              <span>Три в ряд</span>
              <span aria-hidden="true">·</span>
              <span className="text-amber-400 font-semibold">Уровень {stats.level}</span>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1 sm:gap-1.5">
          {/* Sound Toggle */}
          <button
            type="button"
            onClick={onToggleSound}
            title={isMuted ? 'Включить звук' : 'Выключить звук'}
            className={`p-2 rounded-xl border transition-colors ${
              isDark
                ? 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:text-white hover:bg-slate-700'
                : 'bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900'
            }`}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-rose-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          {/* Theme Toggle */}
          <button
            type="button"
            onClick={onToggleTheme}
            title={isDark ? 'Светлая тема' : 'Тёмная тема'}
            className={`p-2 rounded-xl border transition-colors ${
              isDark
                ? 'bg-slate-800/80 border-slate-700/80 text-amber-400 hover:bg-slate-700'
                : 'bg-slate-100 border-slate-200 text-indigo-600 hover:bg-slate-200'
            }`}
          >
            {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Pause Toggle */}
          <button
            type="button"
            onClick={onTogglePause}
            title={isPaused ? 'Продолжить' : 'Пауза'}
            className={`p-2 rounded-xl border transition-colors ${
              isDark
                ? 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:text-white hover:bg-slate-700'
                : 'bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900'
            }`}
          >
            {isPaused ? <Play className="w-4 h-4 text-emerald-400 fill-emerald-400" /> : <Pause className="w-4 h-4" />}
          </button>

          {/* Daily Reward Gift Button */}
          <button
            type="button"
            onClick={onOpenDailyReward}
            title={isDailyRewardAvailable ? 'Ежедневная награда готова!' : 'Ежедневная награда'}
            className={`relative p-2 rounded-xl border transition-all ${
              isDailyRewardAvailable
                ? 'bg-gradient-to-tr from-amber-500/25 to-rose-500/25 border-amber-400/80 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.35)] animate-pulse'
                : isDark
                ? 'bg-slate-800/80 border-slate-700/80 text-slate-400 hover:text-amber-300 hover:bg-slate-700'
                : 'bg-slate-100 border-slate-200 text-slate-600 hover:text-amber-600'
            }`}
          >
            <Gift className="w-4 h-4" />
            {isDailyRewardAvailable && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-rose-500 ring-2 ring-slate-900 animate-ping" />
            )}
          </button>

          {/* Rules Modal */}
          <button
            type="button"
            onClick={onOpenRules}
            title="Правила игры"
            className={`p-2 rounded-xl border transition-colors ${
              isDark
                ? 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:text-white hover:bg-slate-700'
                : 'bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900'
            }`}
          >
            <HelpCircle className="w-4 h-4 text-cyan-400" />
          </button>

          {/* Restart Button */}
          <button
            type="button"
            onClick={onRestart}
            title="Начать заново"
            className={`p-2 rounded-xl border transition-colors ${
              isDark
                ? 'bg-slate-800/80 border-slate-700/80 text-slate-300 hover:text-white hover:bg-slate-700'
                : 'bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900'
            }`}
          >
            <RotateCcw className="w-4 h-4 text-amber-400" />
          </button>

          {/* Android Jetpack Compose Native View */}
          <button
            type="button"
            onClick={onOpenAndroidModal}
            title="Android Jetpack Compose & APK"
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-sm hover:brightness-110 active:scale-95 transition-all ml-1 whitespace-nowrap"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Android APK</span>
          </button>
        </div>
      </div>

      {/* Main HUD Stats Grid */}
      <div className="grid grid-cols-3 gap-2 sm:gap-3">
        {/* Score Card */}
        <div
          className={`relative overflow-hidden rounded-2xl p-2.5 sm:p-3 border backdrop-blur-xl flex flex-col justify-center transition-all ${
            isDark
              ? 'bg-slate-900/60 border-slate-700/60 shadow-md'
              : 'bg-white/80 border-slate-200/80 shadow-sm text-slate-800'
          }`}
        >
          <div className="text-[10px] sm:text-xs font-semibold text-slate-400 uppercase tracking-wider mb-0.5">
            Счёт
          </div>
          <div className="text-lg sm:text-2xl font-black tabular-nums tracking-tight bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent">
            {displayedScore}
          </div>
          <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-0.5">
            <Trophy className="w-3 h-3 text-amber-500 shrink-0" />
            <span className="truncate">Рекорд: {stats.highScore}</span>
          </div>
        </div>

        {/* Moves Left Card */}
        <div
          className={`relative overflow-hidden rounded-2xl p-2.5 sm:p-3 border backdrop-blur-xl flex flex-col justify-center transition-all ${
            stats.movesLeft <= 5
              ? 'bg-rose-950/40 border-rose-500/60 animate-pulse'
              : isDark
              ? 'bg-slate-900/60 border-slate-700/60 shadow-md'
              : 'bg-white/80 border-slate-200/80 shadow-sm text-slate-800'
          }`}
        >
          <div className="text-[10px] sm:text-xs font-semibold text-slate-400 uppercase tracking-wider mb-0.5">
            Ходы
          </div>
          <div
            className={`text-lg sm:text-2xl font-black tabular-nums tracking-tight ${
              stats.movesLeft <= 5
                ? 'text-rose-400 drop-shadow-[0_0_8px_rgba(244,63,94,0.6)]'
                : isDark
                ? 'text-white'
                : 'text-slate-900'
            }`}
          >
            {stats.movesLeft}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5 truncate">
            {stats.movesLeft <= 5 ? 'Осталось мало ходов!' : 'В запасе'}
          </div>
        </div>

        {/* Level & Progress Card */}
        <div
          className={`relative overflow-hidden rounded-2xl p-2.5 sm:p-3 border backdrop-blur-xl flex flex-col justify-center transition-all ${
            isDark
              ? 'bg-slate-900/60 border-slate-700/60 shadow-md'
              : 'bg-white/80 border-slate-200/80 shadow-sm text-slate-800'
          }`}
        >
          <div className="flex items-center justify-between text-[10px] sm:text-xs font-semibold text-slate-400 uppercase tracking-wider mb-0.5">
            <span>Уровень {stats.level}</span>
            <span className="tabular-nums">{pointsInCurrentLevel}/500</span>
          </div>
          <div className="w-full h-2 rounded-full overflow-hidden bg-slate-700/30 my-1">
            <div
              className="h-full bg-gradient-to-r from-cyan-400 via-indigo-500 to-purple-500 transition-all duration-300 rounded-full"
              style={{ width: `${levelProgressPercent}%` }}
            />
          </div>
          <div className="text-[10px] text-slate-400 truncate">
            До след. уровня: {500 - pointsInCurrentLevel} очк.
          </div>
        </div>
      </div>
    </header>
  );
};
