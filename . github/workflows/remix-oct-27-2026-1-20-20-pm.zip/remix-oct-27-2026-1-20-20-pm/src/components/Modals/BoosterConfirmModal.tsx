/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BoosterType } from '../../types/game';
import { Hammer, Zap, Shuffle, AlertCircle } from 'lucide-react';

interface BoosterConfirmModalProps {
  booster: BoosterType | null;
  isOpen: boolean;
  isDark: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

export const BoosterConfirmModal: React.FC<BoosterConfirmModalProps> = ({
  booster,
  isOpen,
  isDark,
  onConfirm,
  onCancel,
}) => {
  if (!isOpen || !booster) return null;

  const boosterInfo = {
    hammer: {
      name: 'Молоток',
      icon: <Hammer className="w-7 h-7 text-amber-400" />,
      color: 'from-amber-500 to-rose-500',
      description: 'Позволит выбрать и разбить любую 1 клетку на игровом поле.',
      actionPrompt: 'Активировать режим молотка?',
    },
    lightning: {
      name: 'Молния',
      icon: <Zap className="w-7 h-7 text-cyan-400" />,
      color: 'from-cyan-400 to-blue-600',
      description: 'Сожжёт всю выбранную горизонтальную строку, принеся очки за все уничтоженные сладости.',
      actionPrompt: 'Активировать режим молнии?',
    },
    shuffle: {
      name: 'Перемешивание',
      icon: <Shuffle className="w-7 h-7 text-purple-400" />,
      color: 'from-purple-500 to-pink-500',
      description: 'Перемешает все элементы на игровом поле случайным образом и обновит расклад.',
      actionPrompt: 'Перемешать все элементы на поле прямо сейчас?',
    },
  }[booster];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-150">
      <div
        className={`relative w-full max-w-sm rounded-3xl p-6 border shadow-2xl transition-all text-center ${
          isDark
            ? 'bg-slate-900/95 border-slate-700 text-slate-100'
            : 'bg-white/95 border-slate-200 text-slate-900'
        }`}
      >
        <div className="w-14 h-14 mx-auto rounded-2xl bg-slate-800/80 border border-slate-700 flex items-center justify-center shadow-lg mb-3">
          {boosterInfo.icon}
        </div>

        <h3 className="text-lg font-bold mb-1">Бустер: {boosterInfo.name}</h3>
        <p className="text-xs text-slate-400 mb-4">{boosterInfo.description}</p>

        <div className="flex items-center justify-center gap-1.5 text-xs text-amber-400 mb-5 font-medium">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{boosterInfo.actionPrompt}</span>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onCancel}
            className={`flex-1 py-2.5 rounded-xl border text-xs font-semibold transition-colors ${
              isDark
                ? 'bg-slate-800/80 border-slate-700 text-slate-300 hover:text-white hover:bg-slate-700'
                : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Отмена
          </button>

          <button
            onClick={onConfirm}
            className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-rose-500 to-indigo-600 text-white font-bold text-xs shadow-md hover:brightness-110 active:scale-95 transition-all"
          >
            Использовать
          </button>
        </div>
      </div>
    </div>
  );
};
