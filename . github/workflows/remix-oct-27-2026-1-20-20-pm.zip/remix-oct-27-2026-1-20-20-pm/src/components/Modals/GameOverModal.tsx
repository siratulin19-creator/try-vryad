/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Trophy, RotateCcw, Home, Sparkles, CheckCircle2 } from 'lucide-react';
import { GameStats, Quest } from '../../types/game';

interface GameOverModalProps {
  isOpen: boolean;
  stats: GameStats;
  quests: Quest[];
  isDark: boolean;
  onPlayAgain: () => void;
  onMainMenu: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  isOpen,
  stats,
  quests,
  isDark,
  onPlayAgain,
  onMainMenu,
}) => {
  if (!isOpen) return null;

  const isNewHighScore = stats.score >= stats.highScore && stats.score > 0;
  const completedQuestsCount = quests.filter((q) => q.completed).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-md rounded-3xl p-6 border shadow-2xl transition-all text-center ${
          isDark
            ? 'bg-slate-900/95 border-slate-700 text-slate-100'
            : 'bg-white/95 border-slate-200 text-slate-900'
        }`}
      >
        {/* Trophy / Result Icon */}
        <div className="w-16 h-16 mx-auto rounded-3xl bg-gradient-to-tr from-amber-400 via-rose-500 to-indigo-600 flex items-center justify-center shadow-xl mb-4">
          <Trophy className="w-8 h-8 text-white" />
        </div>

        <h2 className="text-2xl font-black mb-1">
          {isNewHighScore ? 'Новый рекорд!' : 'Ходы закончились!'}
        </h2>
        <p className="text-xs text-slate-400 mb-5">
          {isNewHighScore
            ? 'Поздравляем, вы превзошли лучший результат!'
            : 'Отличная партия! Попробуйте набрать ещё больше очков.'}
        </p>

        {/* Stats card */}
        <div
          className={`rounded-2xl p-4 mb-5 border space-y-3 ${
            isDark ? 'bg-slate-800/50 border-slate-700/60' : 'bg-slate-50 border-slate-200'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400">Итоговый счёт:</span>
            <span className="text-2xl font-black text-amber-400 tabular-nums">
              {stats.score}
            </span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Лучший рекорд:</span>
            <span className="font-bold tabular-nums text-slate-300">
              {Math.max(stats.score, stats.highScore)}
            </span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Достигнутый уровень:</span>
            <span className="font-bold text-indigo-400">Уровень {stats.level}</span>
          </div>

          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400">Заданий выполнено:</span>
            <span className="font-bold text-emerald-400 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              {completedQuestsCount} из {quests.length}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col gap-2.5">
          <button
            onClick={onPlayAgain}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-rose-500 via-purple-600 to-indigo-600 text-white font-bold text-sm shadow-lg hover:brightness-110 active:scale-98 transition-all flex items-center justify-center gap-2"
          >
            <RotateCcw className="w-4 h-4" />
            Играть снова
          </button>

          <button
            onClick={onMainMenu}
            className={`w-full py-3 rounded-2xl border font-semibold text-xs transition-colors flex items-center justify-center gap-2 ${
              isDark
                ? 'bg-slate-800/80 border-slate-700 text-slate-300 hover:text-white hover:bg-slate-700'
                : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Home className="w-4 h-4" />
            Выйти в меню
          </button>
        </div>
      </div>
    </div>
  );
};
