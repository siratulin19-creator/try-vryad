/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { X, Trophy, Zap, Hammer, Shuffle, Target, Sparkles, Smartphone, MousePointer, Gift, Volume2 } from 'lucide-react';
import { CandyIcon } from '../CandyIcon';
import { ELEMENT_TYPES, ELEMENT_LABELS } from '../../utils/match3Logic';
import { soundManager } from '../../utils/audio';
import { ElementType } from '../../types/game';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
  isDark: boolean;
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose, isDark }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-3xl p-5 sm:p-6 border shadow-2xl transition-all ${
          isDark
            ? 'bg-slate-900/95 border-slate-700 text-slate-100'
            : 'bg-white/95 border-slate-200 text-slate-900'
        }`}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-500 via-purple-500 to-amber-400 flex items-center justify-center shadow-lg">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-xl font-black">Правила игры «Сладкая битва»</h2>
            <p className="text-xs text-slate-400">Красочная логическая игра «Три в ряд»</p>
          </div>
        </div>

        <div className="space-y-4 text-xs sm:text-sm">
          {/* Цель игры */}
          <div className={`p-3.5 rounded-2xl border ${isDark ? 'bg-slate-800/50 border-slate-700/60' : 'bg-slate-50 border-slate-200'}`}>
            <h3 className="font-bold flex items-center gap-2 mb-1.5 text-amber-400">
              <Target className="w-4 h-4" />
              Цель игры
            </h3>
            <p className="text-slate-300 leading-relaxed">
              Собирайте комбинации из 3 и более одинаковых элементов по горизонтали или вертикали.
              После совпадения элементы исчезают, верхние падают вниз, а сверху появляются новые сладости, создавая цепочки комбо!
            </p>
          </div>

          {/* Игровые элементы и уникальные звуки */}
          <div className={`p-3.5 rounded-2xl border ${isDark ? 'bg-slate-800/50 border-slate-700/60' : 'bg-slate-50 border-slate-200'}`}>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-indigo-400">6 элементов и их уникальные звуки</h3>
              <span className="text-[10px] text-slate-400 font-medium">Нажмите для прослушивания</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {ELEMENT_TYPES.map((type) => {
                const soundDescriptions: Record<ElementType, string> = {
                  heart: 'Тёплый бархатистый пульс / биение',
                  star: 'Звёздный хрустальный перезвон',
                  crystal: 'Чистый минеральный хрусталь',
                  lightning: 'Искрящийся электрический разряд',
                  circle: 'Глубокий мистический резонанс',
                  drop: 'Сочный водяной всплеск (бульк)',
                };

                return (
                  <button
                    key={type}
                    type="button"
                    onClick={() => soundManager.playElementPop(type, 1)}
                    title="Нажмите, чтобы послушать звук элемента"
                    className={`flex items-center justify-between p-2 rounded-xl border text-left transition-all active:scale-95 group ${
                      isDark
                        ? 'bg-slate-900/70 border-slate-700/60 hover:border-slate-500 hover:bg-slate-800/80'
                        : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50 shadow-xs'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-7 h-7 shrink-0 group-hover:scale-110 transition-transform">
                        <CandyIcon type={type} />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold truncate">{ELEMENT_LABELS[type]}</div>
                        <div className="text-[10px] text-slate-400 truncate">{soundDescriptions[type]}</div>
                      </div>
                    </div>
                    <div className="p-1 rounded-lg bg-slate-800/50 text-slate-400 group-hover:text-amber-400 transition-colors shrink-0 ml-1">
                      <Volume2 className="w-3.5 h-3.5" />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Очки и комбо */}
          <div className={`p-3.5 rounded-2xl border ${isDark ? 'bg-slate-800/50 border-slate-700/60' : 'bg-slate-50 border-slate-200'}`}>
            <h3 className="font-bold flex items-center gap-2 mb-2 text-emerald-400">
              <Trophy className="w-4 h-4" />
              Начисление очков
            </h3>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-2 rounded-xl bg-slate-700/30">
                <div className="font-extrabold text-sm text-emerald-400">10 очков</div>
                <div className="text-[11px] text-slate-400">За 3 элемента</div>
              </div>
              <div className="p-2 rounded-xl bg-slate-700/30">
                <div className="font-extrabold text-sm text-cyan-400">25 очков</div>
                <div className="text-[11px] text-slate-400">За 4 элемента</div>
              </div>
              <div className="p-2 rounded-xl bg-slate-700/30">
                <div className="font-extrabold text-sm text-amber-400">50 очков</div>
                <div className="text-[11px] text-slate-400">За 5+ элементов</div>
              </div>
            </div>
            <p className="text-[11px] text-slate-400 mt-2">
              Каскадные цепные реакции умножают очки (x1.5, x2, x2.5...)!
            </p>
          </div>

          {/* Бустеры */}
          <div className={`p-3.5 rounded-2xl border ${isDark ? 'bg-slate-800/50 border-slate-700/60' : 'bg-slate-50 border-slate-200'}`}>
            <h3 className="font-bold mb-2 text-rose-400">Бустеры помощи</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
                  <Hammer className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-amber-300">Молоток</span> — удаляет любую выбранную клетку поля.
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0">
                  <Zap className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-cyan-300">Молния</span> — сжигает всю выбранную горизонтальную строку.
                </div>
              </div>
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center shrink-0">
                  <Shuffle className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-bold text-purple-300">Перемешивание</span> — меняет местами все элементы на поле.
                </div>
              </div>
            </div>
          </div>

          {/* Ежедневные награды */}
          <div className={`p-3.5 rounded-2xl border ${isDark ? 'bg-slate-800/50 border-slate-700/60' : 'bg-slate-50 border-slate-200'}`}>
            <h3 className="font-bold flex items-center gap-2 mb-1.5 text-amber-400">
              <Gift className="w-4 h-4" />
              Ежедневные награды
            </h3>
            <p className="text-slate-300 leading-relaxed">
              Заходите в игру каждый день и забирайте подарок! При первом входе за день вы получаете случайный бустер (молоток, молнию или перемешивание). Поддерживайте серию входов каждый день!
            </p>
          </div>

          {/* Управление */}
          <div className={`p-3.5 rounded-2xl border ${isDark ? 'bg-slate-800/50 border-slate-700/60' : 'bg-slate-50 border-slate-200'}`}>
            <h3 className="font-bold mb-2 text-cyan-400">Управление</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="flex items-start gap-2">
                <MousePointer className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">Компьютер:</span> перетаскивание мышью или клик на фигуру, затем на соседнюю клетку.
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Smartphone className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold">Телефон:</span> свайп пальцем в сторону соседа или тап по клетке.
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-5">
          <button
            onClick={onClose}
            className="w-full py-3 rounded-2xl bg-gradient-to-r from-rose-500 via-purple-600 to-indigo-600 text-white font-bold text-sm shadow-lg hover:brightness-110 active:scale-98 transition-all"
          >
            Понятно, играть!
          </button>
        </div>
      </div>
    </div>
  );
};
