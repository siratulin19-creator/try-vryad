/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, Smartphone, Copy, Check, Terminal, Layers, Code, Sparkles, Download } from 'lucide-react';

interface AndroidExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  isDark: boolean;
}

export const AndroidExportModal: React.FC<AndroidExportModalProps> = ({
  isOpen,
  onClose,
  isDark,
}) => {
  const [activeTab, setActiveTab] = useState<'guide' | 'main' | 'vm' | 'ui' | 'gradle'>('guide');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const codeSnippets = {
    guide: `// ИНСТРУКЦИЯ ПО СБОРКЕ APK ДЛЯ ТЕСТИРОВАНИЯ (Android Jetpack Compose)

1. Структура проекта уже подготовлена в папке /android/:
   - android/app/build.gradle.kts
   - android/app/src/main/AndroidManifest.xml
   - android/app/src/main/java/com/sweetbattle/game/MainActivity.kt
   - android/app/src/main/java/com/sweetbattle/game/GameViewModel.kt
   - android/app/src/main/java/com/sweetbattle/game/ui/GameScreen.kt
   - android/app/src/main/res/mipmap/ (иконка приложения и сплэш-экран)

2. Сборка APK через Android Studio:
   - Откройте Android Studio -> File -> Open... -> выберите папку android/
   - Дождитесь синхронизации Gradle
   - Нажмите Build -> Build Bundle(s) / APK(s) -> Build APK(s)
   - Готовый debug APK будет расположен в:
     android/app/build/outputs/apk/debug/app-debug.apk

3. Сборка через командную строку (Terminal):
   cd android
   ./gradlew assembleDebug

4. Установка APK на телефон через ADB:
   adb install -r app/build/outputs/apk/debug/app-debug.apk

5. Поддержка в приложении:
   - Нативный SplashScreen API (экран запуска со сладким логотипом)
   - Адаптивные сенсорные жесты: свайпы и тапы по элементам
   - Оптимизированный рендеринг на Jetpack Compose
   - Сохранение рекорда через DataStore / SharedPreferences
   - Система ежедневных наград со случайным бустером каждый день
   - Все 3 бустера: Молоток, Молния, Перемешивание`,

    main: `package com.sweetbattle.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.sweetbattle.game.ui.GameScreen
import com.sweetbattle.game.ui.theme.SweetBattleTheme

class MainActivity : ComponentActivity() {
    private val viewModel: GameViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        // Нативный сплэш-экран Android 12+
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SweetBattleTheme {
                GameScreen(viewModel = viewModel)
            }
        }
    }
}`,

    vm: `package com.sweetbattle.game

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class ElementType { HEART, STAR, CRYSTAL, LIGHTNING, CIRCLE, DROP }
data class Tile(val id: Long, val type: ElementType, val row: Int, val col: Int)

data class GameUiState(
    val grid: List<List<Tile?>> = List(8) { List(8) { null } },
    val score: Int = 0,
    val level: Int = 1,
    val movesLeft: Int = 30,
    val highScore: Int = 0,
    val hammerCount: Int = 3,
    val lightningCount: Int = 2,
    val shuffleCount: Int = 2,
    val activeBooster: String? = null
)

class GameViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(GameUiState())
    val uiState = _uiState.asStateFlow()

    init {
        startNewGame()
    }

    fun startNewGame() {
        _uiState.value = GameUiState(
            grid = createInitialBoard(),
            score = 0,
            level = 1,
            movesLeft = 30
        )
    }

    private fun createInitialBoard(): List<List<Tile?>> {
        var idCounter = 1L
        return List(8) { r ->
            List(8) { c ->
                val type = ElementType.values()[Random.nextInt(ElementType.values().size)]
                Tile(id = idCounter++, type = type, row = r, col = c)
            }
        }
    }

    fun onSwap(r1: Int, c1: Int, r2: Int, c2: Int) {
        // Проверка смежности и образование совпадения
        viewModelScope.launch {
            // Обработка совпадений, каскадное падение, обновление очков
        }
    }
}`,

    ui: `package com.sweetbattle.game.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.sweetbattle.game.GameViewModel

@Composable
fun GameScreen(viewModel: GameViewModel) {
    val state by viewModel.uiState.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0F172A), Color(0xFF1E1B4B), Color(0xFF090D16))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Верхняя панель HUD (Счёт, Ходы, Уровень)
            HudHeader(score = state.score, moves = state.movesLeft, level = state.level)

            // Сетка 8х8 с поддержкой сенсорных свайпов
            GameBoardCompose(grid = state.grid, onSwap = viewModel::onSwap)

            // Бустеры (Молоток, Молния, Перемешивание)
            BoosterRow(
                hammers = state.hammerCount,
                lightnings = state.lightningCount,
                shuffles = state.shuffleCount
            )
        }
    }
}`,

    gradle: `// android/app/build.gradle.kts
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.sweetbattle.game"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sweetbattle.game"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.core.splashscreen)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
}`,
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl p-5 sm:p-6 border shadow-2xl transition-all ${
          isDark
            ? 'bg-slate-900/95 border-slate-700 text-slate-100'
            : 'bg-white/95 border-slate-200 text-slate-900'
        }`}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg">
            <Smartphone className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-black">
              Android Jetpack Compose & Сборка APK
            </h2>
            <p className="text-xs text-slate-400">
              Нативная кодовая база игры «Сладкая битва» для Android
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-slate-800/60 border border-slate-700/60 mb-3 overflow-x-auto text-xs font-semibold">
          <button
            onClick={() => setActiveTab('guide')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all ${
              activeTab === 'guide'
                ? 'bg-emerald-500 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5" />
              Инструкция сборки APK
            </span>
          </button>
          <button
            onClick={() => setActiveTab('main')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all ${
              activeTab === 'main'
                ? 'bg-emerald-500 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            MainActivity.kt
          </button>
          <button
            onClick={() => setActiveTab('vm')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all ${
              activeTab === 'vm'
                ? 'bg-emerald-500 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            GameViewModel.kt
          </button>
          <button
            onClick={() => setActiveTab('ui')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all ${
              activeTab === 'ui'
                ? 'bg-emerald-500 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            GameScreen.kt
          </button>
          <button
            onClick={() => setActiveTab('gradle')}
            className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all ${
              activeTab === 'gradle'
                ? 'bg-emerald-500 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            build.gradle.kts
          </button>
        </div>

        {/* Code Content Viewer */}
        <div className="relative flex-1 min-h-[300px] overflow-hidden rounded-2xl border border-slate-800 bg-slate-950 p-4">
          <div className="absolute top-3 right-3 z-10">
            <button
              onClick={() => handleCopy(codeSnippets[activeTab])}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold backdrop-blur-md transition-all active:scale-95"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">Скопировано!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Скопировать</span>
                </>
              )}
            </button>
          </div>

          <pre className="h-full max-h-[350px] overflow-y-auto text-xs font-mono text-emerald-300 leading-relaxed pr-24 whitespace-pre-wrap select-text">
            {codeSnippets[activeTab]}
          </pre>
        </div>

        {/* Footer Note */}
        <div className="mt-4 flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
            <Sparkles className="w-4 h-4" />
            Все файлы Android-проекта сохранены в папке /android
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold transition-colors"
          >
            Закрыть
          </button>
        </div>
      </div>
    </div>
  );
};
