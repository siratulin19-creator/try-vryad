/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Play, RotateCcw, HelpCircle, Pause } from 'lucide-react';

interface PauseModalProps {
  isOpen: boolean;
  isDark: boolean;
  onResume: () => void;
  onRestart: () => void;
  onOpenRules: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  isOpen,
  isDark,
  onResume,
  onRestart,
  onOpenRules,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-150">
      <div
        className={`relative w-full max-w-sm rounded-3xl p-6 border shadow-2xl transition-all text-center ${
          isDark
            ? 'bg-slate-900/95 border-slate-700 text-slate-100'
            : 'bg-white/95 border-slate-200 text-slate-900'
        }`}
      >
        <div className="w-14 h-14 mx-auto rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center shadow-lg mb-3">
          <Pause className="w-7 h-7" />
        </div>

        <h3 className="text-xl font-black mb-1">Игра на паузе</h3>
        <p className="text-xs text-slate-400 mb-6">
          Игровое поле заблокировано. Отдохните или продолжите в любой момент.
        </p>

        <div className="flex flex-col gap-2.5">
          <button
            onClick={onResume}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-bold text-sm shadow-lg hover:brightness-110 active:scale-98 transition-all flex items-center justify-center gap-2"
          >
            <Play className="w-4 h-4 fill-white" />
            Продолжить игру
          </button>

          <button
            onClick={onRestart}
            className={`w-full py-3 rounded-2xl border font-semibold text-xs transition-colors flex items-center justify-center gap-2 ${
              isDark
                ? 'bg-slate-800/80 border-slate-700 text-slate-300 hover:text-white hover:bg-slate-700'
                : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <RotateCcw className="w-4 h-4 text-amber-400" />
            Начать заново
          </button>

          <button
            onClick={onOpenRules}
            className={`w-full py-2.5 rounded-2xl border font-semibold text-xs transition-colors flex items-center justify-center gap-2 ${
              isDark
                ? 'bg-slate-850 border-slate-700/60 text-slate-400 hover:text-slate-200'
                : 'bg-white border-slate-200 text-slate-600 hover:text-slate-900'
            }`}
          >
            <HelpCircle className="w-4 h-4 text-cyan-400" />
            Правила игры
          </button>
        </div>
      </div>
    </div>
  );
};
