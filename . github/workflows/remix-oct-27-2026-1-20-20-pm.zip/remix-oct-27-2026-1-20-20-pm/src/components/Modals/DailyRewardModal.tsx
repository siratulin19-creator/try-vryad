/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  Gift,
  Sparkles,
  X,
  Flame,
  Clock,
  CheckCircle2,
  Hammer,
  Zap,
  Shuffle,
  ChevronRight,
} from 'lucide-react';
import { BoosterType } from '../../types/game';
import {
  getTimeUntilNextReward,
  getDailyStreak,
  getLastClaimedBooster,
} from '../../utils/dailyReward';
import { soundManager } from '../../utils/audio';

interface DailyRewardModalProps {
  isOpen: boolean;
  isDark: boolean;
  isRewardAvailable: boolean;
  onClaim: (booster: BoosterType) => void;
  onClose: () => void;
}

export const DailyRewardModal: React.FC<DailyRewardModalProps> = ({
  isOpen,
  isDark,
  isRewardAvailable,
  onClaim,
  onClose,
}) => {
  const [isOpened, setIsOpened] = useState(false);
  const [revealedBooster, setRevealedBooster] = useState<BoosterType | null>(null);
  const [countdown, setCountdown] = useState<string>('');

  // Live countdown timer for already claimed state
  useEffect(() => {
    const updateCountdown = () => {
      const { formatted } = getTimeUntilNextReward();
      setCountdown(formatted);
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, []);

  // Reset internal opened state when modal is opened afresh
  useEffect(() => {
    if (isOpen) {
      if (!isRewardAvailable) {
        setIsOpened(true);
        setRevealedBooster(getLastClaimedBooster());
      } else {
        setIsOpened(false);
        setRevealedBooster(null);
      }
    }
  }, [isOpen, isRewardAvailable]);

  if (!isOpen) return null;

  const currentStreak = getDailyStreak();

  const boosterDetails: Record<
    BoosterType,
    { name: string; description: string; icon: React.ReactNode; color: string; badge: string }
  > = {
    hammer: {
      name: 'Молоток',
      description: 'Удаляет любую выбранную клетку на поле',
      icon: <Hammer className="w-8 h-8 text-amber-300" />,
      color: 'from-amber-500 to-rose-500',
      badge: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    },
    lightning: {
      name: 'Молния',
      description: 'Сжигает всю строку с ярким электрическим разрядом',
      icon: <Zap className="w-8 h-8 text-cyan-300" />,
      color: 'from-cyan-400 to-blue-600',
      badge: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
    },
    shuffle: {
      name: 'Перемешивание',
      description: 'Перемешивает все сладости на игровом поле',
      icon: <Shuffle className="w-8 h-8 text-purple-300" />,
      color: 'from-purple-500 to-pink-500',
      badge: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
    },
  };

  const handleOpenGift = () => {
    if (isOpened || !isRewardAvailable) return;

    // Pick random booster
    const boosterTypes: BoosterType[] = ['hammer', 'lightning', 'shuffle'];
    const selected = boosterTypes[Math.floor(Math.random() * boosterTypes.length)];

    setRevealedBooster(selected);
    setIsOpened(true);

    // Festive audio & confetti
    soundManager.playGiftOpen();
    try {
      confetti({
        particleCount: 70,
        spread: 80,
        origin: { y: 0.55 },
      });
    } catch {}

    // Callback to parent to grant booster and record in localStorage
    onClaim(selected);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div
        className={`relative w-full max-w-md rounded-3xl p-6 sm:p-7 border shadow-2xl transition-all text-center ${
          isDark
            ? 'bg-slate-900/95 border-slate-700/80 text-slate-100'
            : 'bg-white/95 border-slate-200 text-slate-900'
        }`}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          title="Закрыть"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Streak Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold mb-4 bg-amber-500/15 border border-amber-500/30 text-amber-400">
          <Flame className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
          <span>Серия входов: {currentStreak} {currentStreak === 1 ? 'день' : currentStreak < 5 ? 'дня' : 'дней'}</span>
        </div>

        {/* Modal Title */}
        <h2 className="text-2xl sm:text-3xl font-black tracking-tight mb-1 bg-gradient-to-r from-amber-400 via-rose-400 to-indigo-400 bg-clip-text text-transparent">
          {isRewardAvailable && !isOpened
            ? 'Ежедневная награда!'
            : isOpened && isRewardAvailable
            ? 'Поздравляем с наградой!'
            : 'Ежедневная награда получена'}
        </h2>

        <p className="text-xs sm:text-sm text-slate-400 mb-6">
          {isRewardAvailable && !isOpened
            ? 'Первый заход в игру за день! Откройте волшебный подарок и получите бесплатный бустер.'
            : isOpened && isRewardAvailable
            ? 'Бустер успешно начислен в ваш запас и сохранён!'
            : 'Вы уже забрали сегодняшний подарок. Возвращайтесь завтра за новой порцией магии!'}
        </p>

        {/* Gift Box / Reward Display Area */}
        <div className="relative py-2 mb-6 flex flex-col items-center justify-center">
          {isRewardAvailable && !isOpened ? (
            /* Unopened Gift Box with Pulsing Glow */
            <div
              onClick={handleOpenGift}
              className="group relative cursor-pointer flex flex-col items-center justify-center transition-transform hover:scale-105 active:scale-95"
            >
              <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-amber-500/30 via-rose-500/30 to-purple-500/30 blur-2xl animate-pulse" />

              {/* Gift Icon Box */}
              <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-3xl bg-gradient-to-tr from-rose-500 via-purple-600 to-amber-500 p-1 shadow-[0_10px_35px_rgba(244,63,94,0.4)] flex items-center justify-center animate-bounce">
                <div className="w-full h-full rounded-[22px] bg-slate-900/60 backdrop-blur-xs flex flex-col items-center justify-center text-white">
                  <Gift className="w-14 h-14 text-amber-300 drop-shadow-[0_4px_12px_rgba(245,158,11,0.6)]" />
                  <span className="text-[11px] font-black uppercase tracking-wider text-amber-200 mt-1">
                    Нажми меня!
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 text-xs text-amber-400 mt-4 font-semibold">
                <Sparkles className="w-4 h-4 animate-spin" />
                <span>Нажмите на подарок, чтобы открыть</span>
              </div>
            </div>
          ) : revealedBooster ? (
            /* Revealed Booster Card */
            <div className="w-full max-w-xs mx-auto animate-in zoom-in-75 duration-300">
              <div
                className={`relative overflow-hidden rounded-3xl p-5 border shadow-xl bg-gradient-to-b ${
                  isDark
                    ? 'from-slate-800/90 to-slate-900/90 border-slate-700'
                    : 'from-white to-slate-50 border-slate-200'
                }`}
              >
                {/* Visual Glow */}
                <div
                  className={`w-20 h-20 mx-auto rounded-2xl flex items-center justify-center text-white bg-gradient-to-br ${boosterDetails[revealedBooster].color} shadow-lg mb-3`}
                >
                  {boosterDetails[revealedBooster].icon}
                </div>

                <div className="inline-block px-3 py-1 rounded-full text-xs font-black uppercase mb-1.5 bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  +1 Бустер
                </div>

                <h3 className="text-xl font-black mb-1">
                  {boosterDetails[revealedBooster].name}
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {boosterDetails[revealedBooster].description}
                </p>

                {isRewardAvailable && (
                  <div className="mt-3 flex items-center justify-center gap-1.5 text-xs font-semibold text-emerald-400">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Добавлено в инвентарь!</span>
                  </div>
                )}
              </div>
            </div>
          ) : null}

          {/* If already claimed today: Countdown Timer */}
          {!isRewardAvailable && (
            <div className="w-full mt-2 p-3 rounded-2xl border border-slate-700/60 bg-slate-800/40 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-slate-300 font-medium">
                <Clock className="w-4 h-4 text-cyan-400" />
                <span>Следующий подарок:</span>
              </div>
              <span className="font-mono font-black text-sm text-cyan-300 tabular-nums">
                {countdown}
              </span>
            </div>
          )}
        </div>

        {/* 7-Day Streak Mini Schedule */}
        <div className="w-full mb-6 p-3 rounded-2xl border border-slate-700/40 bg-slate-800/30">
          <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 mb-2">
            <span>Прогресс недели</span>
            <span className="text-amber-400 font-bold">День {((currentStreak - 1) % 7) + 1} из 7</span>
          </div>
          <div className="grid grid-cols-7 gap-1 sm:gap-1.5">
            {[1, 2, 3, 4, 5, 6, 7].map((dayNum) => {
              const currentCycleDay = ((currentStreak - 1) % 7) + 1;
              const isPast = dayNum < currentCycleDay || (dayNum === currentCycleDay && !isRewardAvailable);
              const isToday = dayNum === currentCycleDay && isRewardAvailable;

              return (
                <div
                  key={dayNum}
                  className={`flex flex-col items-center justify-center py-2 rounded-xl text-center border transition-all ${
                    isToday
                      ? 'bg-amber-500/20 border-amber-400 text-amber-300 scale-105 shadow-sm ring-1 ring-amber-400/40'
                      : isPast
                      ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-400'
                      : 'bg-slate-800/40 border-slate-700/40 text-slate-500'
                  }`}
                >
                  <span className="text-[10px] font-bold">Д{dayNum}</span>
                  {isPast ? (
                    <CheckCircle2 className="w-3.5 h-3.5 mt-0.5 text-emerald-400" />
                  ) : (
                    <Gift className={`w-3.5 h-3.5 mt-0.5 ${isToday ? 'text-amber-300' : 'text-slate-500'}`} />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom Action Button */}
        {isRewardAvailable && !isOpened ? (
          <button
            onClick={handleOpenGift}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-rose-500 via-purple-600 to-amber-500 text-white font-black text-sm shadow-lg hover:brightness-110 active:scale-98 transition-all flex items-center justify-center gap-2"
          >
            <Gift className="w-4 h-4 text-amber-200" />
            Открыть ежедневный подарок
          </button>
        ) : (
          <button
            onClick={onClose}
            className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-600 to-indigo-600 text-white font-black text-sm shadow-lg hover:brightness-110 active:scale-98 transition-all flex items-center justify-center gap-2"
          >
            <span>Отлично, играть дальше!</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};
