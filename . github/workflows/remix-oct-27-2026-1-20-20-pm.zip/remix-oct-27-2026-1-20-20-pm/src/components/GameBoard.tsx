/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useCallback } from 'react';
import { Tile, Position, BoosterType, GameStatus } from '../types/game';
import { CandyIcon } from './CandyIcon';
import { areAdjacent, BOARD_SIZE } from '../utils/match3Logic';
import { soundManager } from '../utils/audio';

interface GameBoardProps {
  grid: (Tile | null)[][];
  selectedPos: Position | null;
  onTileSelect: (pos: Position) => void;
  onSwapRequest: (p1: Position, p2: Position) => void;
  activeBooster: BoosterType | null;
  onBoosterTarget: (pos: Position) => void;
  status: GameStatus;
  isDark: boolean;
  floatingText: { id: string; text: string; row: number; col: number; color?: string }[];
  lightningRowIndex: number | null;
}

export const GameBoard: React.FC<GameBoardProps> = ({
  grid,
  selectedPos,
  onTileSelect,
  onSwapRequest,
  activeBooster,
  onBoosterTarget,
  status,
  isDark,
  floatingText,
  lightningRowIndex,
}) => {
  const [hoveredPos, setHoveredPos] = useState<Position | null>(null);
  const touchStartRef = useRef<{ x: number; y: number; pos: Position } | null>(null);

  // Mouse / Touch handlers for dragging / swiping
  const handleTouchStart = (e: React.TouchEvent, pos: Position) => {
    if (status !== 'idle' && !activeBooster) return;
    const touch = e.touches[0];
    touchStartRef.current = {
      x: touch.clientX,
      y: touch.clientY,
      pos,
    };
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartRef.current) return;
    if (status !== 'idle' && !activeBooster) {
      touchStartRef.current = null;
      return;
    }

    const touch = e.changedTouches[0];
    const dx = touch.clientX - touchStartRef.current.x;
    const dy = touch.clientY - touchStartRef.current.y;
    const absX = Math.abs(dx);
    const absY = Math.abs(dy);
    const origin = touchStartRef.current.pos;
    touchStartRef.current = null;

    // Minimum swipe threshold in px
    const SWIPE_THRESHOLD = 20;

    if (activeBooster) {
      // Just tap on cell for booster
      if (absX < SWIPE_THRESHOLD && absY < SWIPE_THRESHOLD) {
        onBoosterTarget(origin);
      }
      return;
    }

    if (absX > SWIPE_THRESHOLD || absY > SWIPE_THRESHOLD) {
      let targetRow = origin.row;
      let targetCol = origin.col;

      if (absX > absY) {
        // Horizontal swipe
        targetCol += dx > 0 ? 1 : -1;
      } else {
        // Vertical swipe
        targetRow += dy > 0 ? 1 : -1;
      }

      if (
        targetRow >= 0 &&
        targetRow < BOARD_SIZE &&
        targetCol >= 0 &&
        targetCol < BOARD_SIZE
      ) {
        onSwapRequest(origin, { row: targetRow, col: targetCol });
        return;
      }
    } else {
      // Tap selection
      handleCellClick(origin);
    }
  };

  // Click handler (also works for click-to-select then click-neighbor)
  const handleCellClick = useCallback(
    (pos: Position) => {
      if (status !== 'idle' && !activeBooster) return;

      if (activeBooster) {
        onBoosterTarget(pos);
        return;
      }

      if (!selectedPos) {
        soundManager.playSelect();
        onTileSelect(pos);
      } else {
        // If clicking the same tile, deselect
        if (selectedPos.row === pos.row && selectedPos.col === pos.col) {
          onTileSelect(pos); // toggles off
          return;
        }

        // If clicking an adjacent tile, perform swap
        if (areAdjacent(selectedPos, pos)) {
          onSwapRequest(selectedPos, pos);
        } else {
          // Select new tile instead
          soundManager.playSelect();
          onTileSelect(pos);
        }
      }
    },
    [status, activeBooster, selectedPos, onBoosterTarget, onTileSelect, onSwapRequest]
  );

  return (
    <div className="relative w-full aspect-square max-w-[500px] mx-auto select-none touch-none">
      {/* Outer Glow Container */}
      <div
        className={`relative w-full h-full p-2 sm:p-3 rounded-3xl backdrop-blur-2xl transition-all duration-300 border ${
          isDark
            ? 'bg-slate-900/80 border-slate-700/70 shadow-[0_12px_40px_rgba(0,0,0,0.6),0_0_25px_rgba(59,130,246,0.15)]'
            : 'bg-white/80 border-white/90 shadow-[0_12px_40px_rgba(30,58,138,0.12),0_0_30px_rgba(255,255,255,0.4)]'
        }`}
      >
        {/* Active Lightning beam animation across the selected row */}
        {lightningRowIndex !== null && (
          <div
            className="absolute left-2 right-2 h-[12.5%] pointer-events-none z-30 transition-all duration-300"
            style={{ top: `calc(${lightningRowIndex * 12.5}% + 8px)` }}
          >
            <div className="w-full h-full bg-gradient-to-r from-transparent via-cyan-400 to-transparent opacity-90 blur-xs animate-pulse flex items-center justify-center">
              <div className="w-full h-1 bg-white shadow-[0_0_15px_#22d3ee]" />
            </div>
          </div>
        )}

        {/* 8x8 Grid Canvas */}
        <div className="grid grid-cols-8 grid-rows-8 w-full h-full gap-1 sm:gap-1.5 relative">
          {grid.map((row, rIdx) =>
            row.map((tile, cIdx) => {
              const isSelected = selectedPos?.row === rIdx && selectedPos?.col === cIdx;
              const isHovered = hoveredPos?.row === rIdx && hoveredPos?.col === cIdx;
              const isRowLightningTarget = activeBooster === 'lightning' && hoveredPos?.row === rIdx;
              const isHammerTarget = activeBooster === 'hammer' && isHovered;

              return (
                <div
                  key={`${rIdx}-${cIdx}`}
                  onMouseEnter={() => setHoveredPos({ row: rIdx, col: cIdx })}
                  onMouseLeave={() => setHoveredPos(null)}
                  onClick={() => handleCellClick({ row: rIdx, col: cIdx })}
                  onTouchStart={(e) => handleTouchStart(e, { row: rIdx, col: cIdx })}
                  onTouchEnd={handleTouchEnd}
                  className={`relative flex items-center justify-center rounded-xl transition-all duration-150 cursor-pointer overflow-hidden ${
                    isDark ? 'bg-slate-800/40' : 'bg-slate-100/70'
                  } ${
                    isSelected
                      ? 'ring-3 ring-amber-400 ring-offset-2 ring-offset-slate-900 scale-95 shadow-[0_0_15px_rgba(251,191,36,0.6)] z-10'
                      : ''
                  } ${
                    isHammerTarget
                      ? 'ring-2 ring-rose-500 bg-rose-500/30 shadow-[0_0_12px_rgba(244,63,94,0.6)]'
                      : ''
                  } ${
                    isRowLightningTarget
                      ? 'bg-cyan-500/20 ring-1 ring-cyan-400/60'
                      : ''
                  }`}
                >
                  {tile && (
                    <div
                      className={`w-full h-full p-0.5 sm:p-1 transition-all duration-200 ${
                        tile.isFalling ? 'animate-bounce' : ''
                      } ${
                        tile.isNew ? 'scale-100 animate-in zoom-in-50 duration-200' : ''
                      }`}
                    >
                      <CandyIcon type={tile.type} isMatched={tile.isMatched} />
                    </div>
                  )}

                  {/* Hammer cursor overlay if targeting this tile */}
                  {isHammerTarget && (
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none text-rose-400 font-black text-xs">
                      💥
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Floating floatingText/Combos */}
        {floatingText.map((item) => (
          <div
            key={item.id}
            className={`absolute pointer-events-none z-40 font-black text-sm sm:text-base animate-bounce ${
              item.color || 'text-amber-400 drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)]'
            }`}
            style={{
              top: `${(item.row / BOARD_SIZE) * 100}%`,
              left: `${(item.col / BOARD_SIZE) * 100}%`,
              transform: 'translate(-50%, -50%)',
            }}
          >
            {item.text}
          </div>
        ))}
      </div>
    </div>
  );
};
