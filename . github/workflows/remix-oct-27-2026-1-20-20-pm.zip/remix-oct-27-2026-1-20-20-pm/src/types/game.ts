/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ElementType = 'heart' | 'star' | 'crystal' | 'lightning' | 'circle' | 'drop';

export interface Position {
  row: number;
  col: number;
}

export interface Tile {
  id: string;
  type: ElementType;
  row: number;
  col: number;
  isMatched?: boolean;
  isNew?: boolean;
  isFalling?: boolean;
}

export interface MatchGroup {
  type: ElementType;
  positions: Position[];
  length: number;
  isHorizontal: boolean;
}

export type BoosterType = 'hammer' | 'lightning' | 'shuffle';

export interface BoosterState {
  hammer: number;
  lightning: number;
  shuffle: number;
}

export type QuestType = 'score' | 'red_hearts' | 'combo4';

export interface Quest {
  id: string;
  type: QuestType;
  title: string;
  description: string;
  current: number;
  target: number;
  completed: boolean;
  rewardText: string;
  rewardType: 'moves' | 'booster_hammer' | 'booster_lightning' | 'score';
}

export interface GameStats {
  score: number;
  level: number;
  movesLeft: number;
  highScore: number;
  combo: number;
}

export type GameStatus = 'idle' | 'swapping' | 'matching' | 'dropping' | 'paused' | 'game_over' | 'level_cleared';
