/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BoosterState, BoosterType } from '../types/game';

export const DAILY_REWARD_DATE_KEY = 'sweet_battle_last_daily_date';
export const DAILY_REWARD_STREAK_KEY = 'sweet_battle_daily_streak';
export const DAILY_REWARD_LAST_BOOSTER_KEY = 'sweet_battle_last_reward_booster';
export const SAVED_BOOSTERS_KEY = 'sweet_battle_boosters';

export const DEFAULT_BOOSTERS: BoosterState = {
  hammer: 3,
  lightning: 2,
  shuffle: 2,
};

// Returns current local calendar date string YYYY-MM-DD
export function getTodayDateString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

// Checks if today is consecutive day compared to lastDateStr
function isConsecutiveDay(lastDateStr: string, todayStr: string): boolean {
  try {
    const [ly, lm, ld] = lastDateStr.split('-').map(Number);
    const [ty, tm, td] = todayStr.split('-').map(Number);
    const lastDate = new Date(ly, lm - 1, ld);
    const today = new Date(ty, tm - 1, td);
    const diffTime = today.getTime() - lastDate.getTime();
    const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
    return diffDays === 1;
  } catch {
    return false;
  }
}

// Check if daily reward is available today
export function isDailyRewardAvailable(): boolean {
  const lastDate = localStorage.getItem(DAILY_REWARD_DATE_KEY);
  const today = getTodayDateString();
  return lastDate !== today;
}

// Get current streak
export function getDailyStreak(): number {
  const saved = localStorage.getItem(DAILY_REWARD_STREAK_KEY);
  return saved ? Math.max(1, parseInt(saved, 10)) : 1;
}

// Pick a random booster from the 3 available types
export function getRandomBooster(): BoosterType {
  const boosters: BoosterType[] = ['hammer', 'lightning', 'shuffle'];
  const randomIndex = Math.floor(Math.random() * boosters.length);
  return boosters[randomIndex];
}

// Save claim info to localStorage
export function recordDailyRewardClaim(booster: BoosterType): { newStreak: number } {
  const today = getTodayDateString();
  const lastDate = localStorage.getItem(DAILY_REWARD_DATE_KEY);
  let currentStreak = getDailyStreak();

  if (lastDate && isConsecutiveDay(lastDate, today)) {
    currentStreak += 1;
  } else if (!lastDate || lastDate !== today) {
    currentStreak = 1;
  }

  localStorage.setItem(DAILY_REWARD_DATE_KEY, today);
  localStorage.setItem(DAILY_REWARD_STREAK_KEY, String(currentStreak));
  localStorage.setItem(DAILY_REWARD_LAST_BOOSTER_KEY, booster);

  return { newStreak: currentStreak };
}

// Get last claimed booster type
export function getLastClaimedBooster(): BoosterType | null {
  return (localStorage.getItem(DAILY_REWARD_LAST_BOOSTER_KEY) as BoosterType) || null;
}

// Calculate time remaining until next day (midnight)
export function getTimeUntilNextReward(): { hours: number; minutes: number; seconds: number; formatted: string } {
  const now = new Date();
  const midnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0);
  const diffMs = Math.max(0, midnight.getTime() - now.getTime());

  const hours = Math.floor(diffMs / (1000 * 60 * 60));
  const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);

  const formatted = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  return { hours, minutes, seconds, formatted };
}

// Booster inventory persistence
export function loadSavedBoosters(): BoosterState {
  try {
    const saved = localStorage.getItem(SAVED_BOOSTERS_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        hammer: typeof parsed.hammer === 'number' ? parsed.hammer : DEFAULT_BOOSTERS.hammer,
        lightning: typeof parsed.lightning === 'number' ? parsed.lightning : DEFAULT_BOOSTERS.lightning,
        shuffle: typeof parsed.shuffle === 'number' ? parsed.shuffle : DEFAULT_BOOSTERS.shuffle,
      };
    }
  } catch {}
  return DEFAULT_BOOSTERS;
}

export function saveBoosters(boosters: BoosterState): void {
  try {
    localStorage.setItem(SAVED_BOOSTERS_KEY, JSON.stringify(boosters));
  } catch {}
}
