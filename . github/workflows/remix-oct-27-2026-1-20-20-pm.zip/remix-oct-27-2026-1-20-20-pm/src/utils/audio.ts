import { ElementType } from '../types/game';

// Web Audio API sound synthesizer for "Сладкая битва"
// Operates entirely without external audio files and complies with user gesture requirements.

class SoundManager {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;

  constructor() {
    const saved = localStorage.getItem('sweet_battle_muted');
    if (saved !== null) {
      this.isMuted = saved === 'true';
    }
  }

  private initCtx(): AudioContext | null {
    if (this.isMuted) return null;
    if (!this.ctx) {
      const AudioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtxClass) {
        this.ctx = new AudioCtxClass();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    localStorage.setItem('sweet_battle_muted', String(this.isMuted));
    return this.isMuted;
  }

  // Soft click / tile selection pop
  public playSelect(): void {
    const ctx = this.initCtx();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(480, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(720, ctx.currentTime + 0.05);

      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.06);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.06);
    } catch {
      // Audio errors silenced
    }
  }

  // Swap swoosh
  public playSwap(): void {
    const ctx = this.initCtx();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(540, ctx.currentTime + 0.1);

      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.12);
    } catch {}
  }

  // Invalid swap bounce
  public playInvalid(): void {
    const ctx = this.initCtx();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(180, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(120, ctx.currentTime + 0.15);

      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.16);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.16);
    } catch {}
  }

  // -------------------------------------------------------------
  // Unique sound effects for each element type when cleared
  // -------------------------------------------------------------

  // 1. Красное сердце: Тёплый бархатистый пульс / биение сердца / сочный лоп
  private playHeartSound(ctx: AudioContext, startTime: number, combo: number = 1): void {
    const pitchOffset = Math.min((combo - 1) * 20, 100);
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const filter = ctx.createBiquadFilter();

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(520 + pitchOffset, startTime);

    osc.type = 'sine';
    // Gentle heartbeat sweep
    osc.frequency.setValueAtTime(170 + pitchOffset, startTime);
    osc.frequency.exponentialRampToValueAtTime(260 + pitchOffset, startTime + 0.04);
    osc.frequency.exponentialRampToValueAtTime(140 + pitchOffset, startTime + 0.16);

    gain.gain.setValueAtTime(0, startTime);
    gain.gain.linearRampToValueAtTime(0.24, startTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.22);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    osc.start(startTime);
    osc.stop(startTime + 0.23);

    // Second micro-thump pulse (heartbeat rhythm)
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(140 + pitchOffset, startTime + 0.08);
    osc2.frequency.exponentialRampToValueAtTime(90 + pitchOffset, startTime + 0.18);

    gain2.gain.setValueAtTime(0, startTime + 0.08);
    gain2.gain.linearRampToValueAtTime(0.14, startTime + 0.09);
    gain2.gain.exponentialRampToValueAtTime(0.001, startTime + 0.22);

    osc2.connect(gain2);
    gain2.connect(ctx.destination);

    osc2.start(startTime + 0.08);
    osc2.stop(startTime + 0.23);
  }

  // 2. Синяя звезда: Космический хрустальный перезвон / звёздный глокеншпиль
  private playStarSound(ctx: AudioContext, startTime: number, combo: number = 1): void {
    const pitchShift = Math.min((combo - 1) * 0.1, 0.4);
    // Celestial shimmer triad
    const freqs = [1046.5 * (1 + pitchShift), 1318.5 * (1 + pitchShift), 1567.98 * (1 + pitchShift)];

    freqs.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const noteTime = startTime + idx * 0.035;

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, noteTime);
      // Subtle astral vibrato
      osc.frequency.linearRampToValueAtTime(freq * 1.015, noteTime + 0.1);
      osc.frequency.linearRampToValueAtTime(freq, noteTime + 0.25);

      gain.gain.setValueAtTime(0, noteTime);
      gain.gain.linearRampToValueAtTime(0.15, noteTime + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.001, noteTime + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(noteTime);
      osc.stop(noteTime + 0.31);
    });
  }

  // 3. Зелёный кристалл: Звонкий чистый минеральный хрусталь с акустическим биением
  private playCrystalSound(ctx: AudioContext, startTime: number, combo: number = 1): void {
    const baseFreq = 1760 + Math.min((combo - 1) * 120, 600);

    // Two slightly detuned oscillators create realistic crystal acoustic beats
    const detunes = [0, 14];
    detunes.forEach((detune) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(baseFreq * 1.1, startTime);
      filter.Q.setValueAtTime(10, startTime);

      osc.type = 'sine';
      osc.frequency.setValueAtTime(baseFreq + detune, startTime);

      gain.gain.setValueAtTime(0, startTime);
      gain.gain.linearRampToValueAtTime(0.16, startTime + 0.005);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.32);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + 0.33);
    });
  }

  // 4. Жёлтая молния: Электрический искрящийся щелчок / статический разряд
  private playLightningSound(ctx: AudioContext, startTime: number, combo: number = 1): void {
    const pitchOffset = Math.min((combo - 1) * 80, 400);

    // Fast static zap
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const filter = ctx.createBiquadFilter();

    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1800 + pitchOffset, startTime);
    filter.Q.setValueAtTime(4, startTime);

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(1300 + pitchOffset, startTime);
    osc.frequency.exponentialRampToValueAtTime(240, startTime + 0.045);

    gain.gain.setValueAtTime(0, startTime);
    gain.gain.linearRampToValueAtTime(0.2, startTime + 0.005);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.08);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    osc.start(startTime);
    osc.stop(startTime + 0.085);

    // Secondary micro-spark
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'square';
    osc2.frequency.setValueAtTime(950 + pitchOffset, startTime + 0.03);
    osc2.frequency.exponentialRampToValueAtTime(320, startTime + 0.07);

    gain2.gain.setValueAtTime(0, startTime + 0.03);
    gain2.gain.linearRampToValueAtTime(0.12, startTime + 0.035);
    gain2.gain.exponentialRampToValueAtTime(0.001, startTime + 0.1);

    osc2.connect(gain2);
    gain2.connect(ctx.destination);

    osc2.start(startTime + 0.03);
    osc2.stop(startTime + 0.11);
  }

  // 5. Фиолетовый круг / сфера: Глубокий мистический резонанс поющей чаши / космической сферы
  private playCircleSound(ctx: AudioContext, startTime: number, combo: number = 1): void {
    const baseFreq = 349.23 * (1 + Math.min((combo - 1) * 0.08, 0.4)); // F4

    // Fundamental with smooth pitch scoop
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();

    osc1.type = 'triangle';
    osc1.frequency.setValueAtTime(baseFreq * 0.85, startTime);
    osc1.frequency.exponentialRampToValueAtTime(baseFreq, startTime + 0.06);

    gain1.gain.setValueAtTime(0, startTime);
    gain1.gain.linearRampToValueAtTime(0.2, startTime + 0.02);
    gain1.gain.exponentialRampToValueAtTime(0.001, startTime + 0.35);

    osc1.connect(gain1);
    gain1.connect(ctx.destination);

    osc1.start(startTime);
    osc1.stop(startTime + 0.36);

    // Ethereal octave shimmer
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();

    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(baseFreq * 2, startTime + 0.02);

    gain2.gain.setValueAtTime(0, startTime + 0.02);
    gain2.gain.linearRampToValueAtTime(0.1, startTime + 0.05);
    gain2.gain.exponentialRampToValueAtTime(0.001, startTime + 0.38);

    osc2.connect(gain2);
    gain2.connect(ctx.destination);

    osc2.start(startTime + 0.02);
    osc2.stop(startTime + 0.39);
  }

  // 6. Оранжевая капля: Сочный влажный "бульк" / звонкий всплеск капли воды (water bloop)
  private playDropSound(ctx: AudioContext, startTime: number, combo: number = 1): void {
    const pitchOffset = Math.min((combo - 1) * 40, 200);

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    // Upward frequency sweep (classic physics of a water drop bubble)
    osc.frequency.setValueAtTime(420 + pitchOffset, startTime);
    osc.frequency.exponentialRampToValueAtTime(1150 + pitchOffset, startTime + 0.045);
    osc.frequency.linearRampToValueAtTime(950 + pitchOffset, startTime + 0.12);

    gain.gain.setValueAtTime(0, startTime);
    gain.gain.linearRampToValueAtTime(0.26, startTime + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.22);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(startTime);
    osc.stop(startTime + 0.23);

    // Subtle droplet ripple
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(1450 + pitchOffset, startTime + 0.04);
    osc2.frequency.exponentialRampToValueAtTime(800 + pitchOffset, startTime + 0.15);

    gain2.gain.setValueAtTime(0, startTime + 0.04);
    gain2.gain.linearRampToValueAtTime(0.08, startTime + 0.05);
    gain2.gain.exponentialRampToValueAtTime(0.001, startTime + 0.18);

    osc2.connect(gain2);
    gain2.connect(ctx.destination);

    osc2.start(startTime + 0.04);
    osc2.stop(startTime + 0.19);
  }

  // Play single element sound (useful for previewing or single removal like hammer)
  public playElementPop(type: ElementType, combo: number = 1): void {
    const ctx = this.initCtx();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;
      switch (type) {
        case 'heart':
          this.playHeartSound(ctx, now, combo);
          break;
        case 'star':
          this.playStarSound(ctx, now, combo);
          break;
        case 'crystal':
          this.playCrystalSound(ctx, now, combo);
          break;
        case 'lightning':
          this.playLightningSound(ctx, now, combo);
          break;
        case 'circle':
          this.playCircleSound(ctx, now, combo);
          break;
        case 'drop':
          this.playDropSound(ctx, now, combo);
          break;
      }
    } catch {}
  }

  // Match chime with pentatonic harmonic escalation + unique element sound synthesis
  public playMatchWithElements(types: ElementType[], combo: number = 1, matchCount: number = 3): void {
    const ctx = this.initCtx();
    if (!ctx) return;
    try {
      const now = ctx.currentTime;

      // 1. Play unique element sound(s) for the matched candy types
      const uniqueTypes = Array.from(new Set(types));
      uniqueTypes.forEach((type, idx) => {
        const offset = idx * 0.04;
        switch (type) {
          case 'heart':
            this.playHeartSound(ctx, now + offset, combo);
            break;
          case 'star':
            this.playStarSound(ctx, now + offset, combo);
            break;
          case 'crystal':
            this.playCrystalSound(ctx, now + offset, combo);
            break;
          case 'lightning':
            this.playLightningSound(ctx, now + offset, combo);
            break;
          case 'circle':
            this.playCircleSound(ctx, now + offset, combo);
            break;
          case 'drop':
            this.playDropSound(ctx, now + offset, combo);
            break;
        }
      });

      // 2. Pentatonic chord chime for musical cascade satisfaction
      const scale = [523.25, 587.33, 659.25, 783.99, 880.0, 1046.5, 1174.66, 1318.51];
      const baseIndex = Math.min((combo - 1) * 2, scale.length - 3);
      const noteCount = matchCount >= 5 ? 3 : matchCount >= 4 ? 2 : 1;

      for (let i = 0; i < noteCount; i++) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const freq = scale[Math.min(baseIndex + i, scale.length - 1)];

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + i * 0.05);

        gain.gain.setValueAtTime(0, now + i * 0.05);
        gain.gain.linearRampToValueAtTime(0.14, now + i * 0.05 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.05 + 0.32);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + i * 0.05);
        osc.stop(now + i * 0.05 + 0.33);
      }
    } catch {}
  }

  // Backward compatible match chime
  public playMatch(combo: number = 1, matchCount: number = 3): void {
    this.playMatchWithElements([], combo, matchCount);
  }

  // Booster: Hammer smash
  public playBoosterHammer(): void {
    const ctx = this.initCtx();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(240, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(60, ctx.currentTime + 0.22);

      gain.gain.setValueAtTime(0.28, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);

      // Glass shatter sparkle
      setTimeout(() => {
        if (!this.ctx || this.isMuted) return;
        const osc2 = this.ctx.createOscillator();
        const gain2 = this.ctx.createGain();
        osc2.type = 'sine';
        osc2.frequency.setValueAtTime(1400, this.ctx.currentTime);
        osc2.frequency.exponentialRampToValueAtTime(400, this.ctx.currentTime + 0.15);
        gain2.gain.setValueAtTime(0.1, this.ctx.currentTime);
        gain2.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.15);
        osc2.connect(gain2);
        gain2.connect(this.ctx.destination);
        osc2.start();
        osc2.stop(this.ctx.currentTime + 0.15);
      }, 50);
    } catch {}
  }

  // Booster: Lightning zap
  public playBoosterLightning(): void {
    const ctx = this.initCtx();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(800, ctx.currentTime);
      osc.frequency.linearRampToValueAtTime(200, ctx.currentTime + 0.25);

      gain.gain.setValueAtTime(0.18, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.28);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.28);
    } catch {}
  }

  // Booster: Shuffle sparkle flutter
  public playBoosterShuffle(): void {
    const ctx = this.initCtx();
    if (!ctx) return;
    try {
      const freqs = [350, 480, 600, 720, 850];
      freqs.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.05);

        gain.gain.setValueAtTime(0.1, ctx.currentTime + idx * 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.05 + 0.18);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.05);
        osc.stop(ctx.currentTime + idx * 0.05 + 0.2);
      });
    } catch {}
  }

  // Level Up celebratory fanfare
  public playLevelUp(): void {
    const ctx = this.initCtx();
    if (!ctx) return;
    try {
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C E G C
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.1);

        gain.gain.setValueAtTime(0.15, ctx.currentTime + idx * 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.1 + 0.35);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.1);
        osc.stop(ctx.currentTime + idx * 0.1 + 0.36);
      });
    } catch {}
  }

  // Quest Completed reward chime
  public playQuestComplete(): void {
    const ctx = this.initCtx();
    if (!ctx) return;
    try {
      const notes = [659.25, 880.0, 1174.66]; // E A D
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.08);

        gain.gain.setValueAtTime(0.14, ctx.currentTime + idx * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.08 + 0.25);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.08);
        osc.stop(ctx.currentTime + idx * 0.08 + 0.26);
      });
    } catch {}
  }

  // Game over sound
  public playGameOver(): void {
    const ctx = this.initCtx();
    if (!ctx) return;
    try {
      const notes = [440, 392, 349.23, 293.66];
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.12);

        gain.gain.setValueAtTime(0.12, ctx.currentTime + idx * 0.12);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.12 + 0.3);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.12);
        osc.stop(ctx.currentTime + idx * 0.12 + 0.32);
      });
    } catch {}
  }

  // Daily Gift opened fanfare
  public playGiftOpen(): void {
    const ctx = this.initCtx();
    if (!ctx) return;
    try {
      const chords = [523.25, 659.25, 783.99, 1046.5, 1318.51]; // C E G C E
      chords.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.07);

        gain.gain.setValueAtTime(0.01, ctx.currentTime + idx * 0.07);
        gain.gain.linearRampToValueAtTime(0.18, ctx.currentTime + idx * 0.07 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.07 + 0.4);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.07);
        osc.stop(ctx.currentTime + idx * 0.07 + 0.42);
      });
    } catch {}
  }
}

export const soundManager = new SoundManager();
