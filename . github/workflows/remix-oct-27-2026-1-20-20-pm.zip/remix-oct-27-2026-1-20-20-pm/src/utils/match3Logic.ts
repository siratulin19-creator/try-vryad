/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ElementType, Position, Tile, MatchGroup, Quest } from '../types/game';

export const BOARD_SIZE = 8;

export const ELEMENT_TYPES: ElementType[] = [
  'heart',     // Красное сердце
  'star',      // Синяя звезда
  'crystal',   // Зелёный кристалл
  'lightning', // Жёлтая молния
  'circle',    // Фиолетовый круг
  'drop',      // Оранжевая капля
];

export const ELEMENT_LABELS: Record<ElementType, string> = {
  heart: 'Красное сердце',
  star: 'Синяя звезда',
  crystal: 'Зелёный кристалл',
  lightning: 'Жёлтая молния',
  circle: 'Фиолетовый круг',
  drop: 'Оранжевая капля',
};

// Generate a random element type, optionally excluding some
export function getRandomElementType(exclude: ElementType[] = []): ElementType {
  const allowed = ELEMENT_TYPES.filter(t => !exclude.includes(t));
  const pool = allowed.length > 0 ? allowed : ELEMENT_TYPES;
  return pool[Math.floor(Math.random() * pool.length)];
}

// Generate unique ID for each tile
let tileCounter = 0;
export function createTile(type: ElementType, row: number, col: number, isNew: boolean = false): Tile {
  tileCounter += 1;
  return {
    id: `tile_${tileCounter}_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    type,
    row,
    col,
    isNew,
  };
}

// Check if two positions are adjacent (orthogonal only)
export function areAdjacent(p1: Position, p2: Position): boolean {
  const rowDiff = Math.abs(p1.row - p2.row);
  const colDiff = Math.abs(p1.col - p2.col);
  return (rowDiff === 1 && colDiff === 0) || (rowDiff === 0 && colDiff === 1);
}

// Clone 2D grid of tiles
export function cloneGrid(grid: (Tile | null)[][]): (Tile | null)[][] {
  return grid.map((row, rIdx) =>
    row.map((tile, cIdx) => (tile ? { ...tile, row: rIdx, col: cIdx } : null))
  );
}

// Find all matches on the grid
export function findMatches(grid: (Tile | null)[][]): {
  matchGroups: MatchGroup[];
  matchedPositions: Position[];
  hasMatchOf4OrMore: boolean;
  collectedCountByType: Record<ElementType, number>;
} {
  const matchedCoords = new Set<string>();
  const matchGroups: MatchGroup[] = [];
  const collectedCountByType: Record<ElementType, number> = {
    heart: 0,
    star: 0,
    crystal: 0,
    lightning: 0,
    circle: 0,
    drop: 0,
  };

  // 1. Horizontal check
  for (let r = 0; r < BOARD_SIZE; r++) {
    let matchStart = 0;
    while (matchStart < BOARD_SIZE) {
      const currentTile = grid[r][matchStart];
      if (!currentTile) {
        matchStart++;
        continue;
      }

      let matchEnd = matchStart + 1;
      while (
        matchEnd < BOARD_SIZE &&
        grid[r][matchEnd] &&
        grid[r][matchEnd]!.type === currentTile.type
      ) {
        matchEnd++;
      }

      const matchLength = matchEnd - matchStart;
      if (matchLength >= 3) {
        const positions: Position[] = [];
        for (let c = matchStart; c < matchEnd; c++) {
          positions.push({ row: r, col: c });
          matchedCoords.add(`${r},${c}`);
        }
        matchGroups.push({
          type: currentTile.type,
          positions,
          length: matchLength,
          isHorizontal: true,
        });
      }
      matchStart = matchEnd;
    }
  }

  // 2. Vertical check
  for (let c = 0; c < BOARD_SIZE; c++) {
    let matchStart = 0;
    while (matchStart < BOARD_SIZE) {
      const currentTile = grid[matchStart][c];
      if (!currentTile) {
        matchStart++;
        continue;
      }

      let matchEnd = matchStart + 1;
      while (
        matchEnd < BOARD_SIZE &&
        grid[matchEnd][c] &&
        grid[matchEnd][c]!.type === currentTile.type
      ) {
        matchEnd++;
      }

      const matchLength = matchEnd - matchStart;
      if (matchLength >= 3) {
        const positions: Position[] = [];
        for (let r = matchStart; r < matchEnd; r++) {
          positions.push({ row: r, col: c });
          matchedCoords.add(`${r},${c}`);
        }
        matchGroups.push({
          type: currentTile.type,
          positions,
          length: matchLength,
          isHorizontal: false,
        });
      }
      matchStart = matchEnd;
    }
  }

  // Convert matched coordinates to position list and count by type
  const matchedPositions: Position[] = [];
  let hasMatchOf4OrMore = false;

  matchedCoords.forEach(coord => {
    const [r, c] = coord.split(',').map(Number);
    matchedPositions.push({ row: r, col: c });
    const tile = grid[r][c];
    if (tile) {
      collectedCountByType[tile.type] = (collectedCountByType[tile.type] || 0) + 1;
    }
  });

  for (const group of matchGroups) {
    if (group.length >= 4) {
      hasMatchOf4OrMore = true;
    }
  }

  return {
    matchGroups,
    matchedPositions,
    hasMatchOf4OrMore,
    collectedCountByType,
  };
}

// Calculate score based on user specifications:
// - 3 elements = 10 pts
// - 4 elements = 25 pts
// - 5+ elements = 50 pts
// Includes combo multiplier (1.0 for first match, +0.5 for each cascade step)
export function calculateMatchScore(matchGroups: MatchGroup[], combo: number = 1): number {
  if (matchGroups.length === 0) return 0;

  let basePoints = 0;
  for (const group of matchGroups) {
    if (group.length === 3) {
      basePoints += 10;
    } else if (group.length === 4) {
      basePoints += 25;
    } else if (group.length >= 5) {
      basePoints += 50;
    }
  }

  // Combo multiplier: combo 1 = 1x, combo 2 = 1.5x, combo 3 = 2x, etc.
  const multiplier = 1 + (Math.max(1, combo) - 1) * 0.5;
  return Math.round(basePoints * multiplier);
}

// Check if a potential swap results in a match
export function testSwapProducesMatch(
  grid: (Tile | null)[][],
  p1: Position,
  p2: Position
): boolean {
  if (!grid[p1.row][p1.col] || !grid[p2.row][p2.col]) return false;

  // Temporarily swap
  const tempGrid = cloneGrid(grid);
  const t1 = tempGrid[p1.row][p1.col]!;
  const t2 = tempGrid[p2.row][p2.col]!;

  tempGrid[p1.row][p1.col] = { ...t2, row: p1.row, col: p1.col };
  tempGrid[p2.row][p2.col] = { ...t1, row: p2.row, col: p2.col };

  const matches = findMatches(tempGrid);
  return matches.matchedPositions.length > 0;
}

// Check if the board has ANY possible valid moves
export function hasPossibleMoves(grid: (Tile | null)[][]): boolean {
  for (let r = 0; r < BOARD_SIZE; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      const p1: Position = { row: r, col: c };

      // Test horizontal right
      if (c + 1 < BOARD_SIZE) {
        const p2: Position = { row: r, col: c + 1 };
        if (testSwapProducesMatch(grid, p1, p2)) return true;
      }

      // Test vertical down
      if (r + 1 < BOARD_SIZE) {
        const p2: Position = { row: r + 1, col: c };
        if (testSwapProducesMatch(grid, p1, p2)) return true;
      }
    }
  }
  return false;
}

// Find a single valid move for hint
export function findHintMove(grid: (Tile | null)[][]): [Position, Position] | null {
  for (let r = 0; r < BOARD_SIZE; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      const p1: Position = { row: r, col: c };

      // Right
      if (c + 1 < BOARD_SIZE) {
        const p2: Position = { row: r, col: c + 1 };
        if (testSwapProducesMatch(grid, p1, p2)) return [p1, p2];
      }

      // Down
      if (r + 1 < BOARD_SIZE) {
        const p2: Position = { row: r + 1, col: c };
        if (testSwapProducesMatch(grid, p1, p2)) return [p1, p2];
      }
    }
  }
  return null;
}

// Generate an initial board with NO immediate matches, but with at least 1 valid move
export function createInitialBoard(): (Tile | null)[][] {
  let attempts = 0;

  while (attempts < 100) {
    attempts++;
    const grid: (Tile | null)[][] = Array(BOARD_SIZE)
      .fill(null)
      .map(() => Array(BOARD_SIZE).fill(null));

    for (let r = 0; r < BOARD_SIZE; r++) {
      for (let c = 0; c < BOARD_SIZE; c++) {
        // Exclude elements that would create a match of 3 right away
        const exclude: ElementType[] = [];

        // Exclude horizontal match
        if (c >= 2) {
          const t1 = grid[r][c - 1]?.type;
          const t2 = grid[r][c - 2]?.type;
          if (t1 && t1 === t2) {
            exclude.push(t1);
          }
        }

        // Exclude vertical match
        if (r >= 2) {
          const t1 = grid[r - 1][c]?.type;
          const t2 = grid[r - 2][c]?.type;
          if (t1 && t1 === t2) {
            exclude.push(t1);
          }
        }

        const type = getRandomElementType(exclude);
        grid[r][c] = createTile(type, r, c);
      }
    }

    // Ensure no accidental matches and at least one possible move
    const matches = findMatches(grid);
    if (matches.matchedPositions.length === 0 && hasPossibleMoves(grid)) {
      return grid;
    }
  }

  // Fallback: manually construct guaranteed playable board
  return createFallbackPlayableBoard();
}

function createFallbackPlayableBoard(): (Tile | null)[][] {
  const grid: (Tile | null)[][] = Array(BOARD_SIZE)
    .fill(null)
    .map(() => Array(BOARD_SIZE).fill(null));

  for (let r = 0; r < BOARD_SIZE; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      // Deterministic staggered pattern
      const type = ELEMENT_TYPES[(r * 2 + c) % ELEMENT_TYPES.length];
      grid[r][c] = createTile(type, r, c);
    }
  }

  return grid;
}

// Reshuffle existing tiles without creating matches and ensuring valid moves exist
export function shuffleBoard(grid: (Tile | null)[][]): (Tile | null)[][] {
  const allTypes: ElementType[] = [];
  for (let r = 0; r < BOARD_SIZE; r++) {
    for (let c = 0; c < BOARD_SIZE; c++) {
      if (grid[r][c]) {
        allTypes.push(grid[r][c]!.type);
      }
    }
  }

  let tries = 0;
  while (tries < 100) {
    tries++;
    // Fisher-Yates shuffle
    const shuffled = [...allTypes];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }

    const newGrid: (Tile | null)[][] = Array(BOARD_SIZE)
      .fill(null)
      .map(() => Array(BOARD_SIZE).fill(null));

    let idx = 0;
    for (let r = 0; r < BOARD_SIZE; r++) {
      for (let c = 0; c < BOARD_SIZE; c++) {
        newGrid[r][c] = createTile(shuffled[idx++], r, c);
      }
    }

    const matches = findMatches(newGrid);
    if (matches.matchedPositions.length === 0 && hasPossibleMoves(newGrid)) {
      return newGrid;
    }
  }

  // If hard to shuffle without matches, regenerate fresh board
  return createInitialBoard();
}

// Gravity step: drop existing tiles down into empty spaces
export function applyGravity(grid: (Tile | null)[][]): {
  newGrid: (Tile | null)[][];
  movedTilesCount: number;
} {
  const newGrid: (Tile | null)[][] = Array(BOARD_SIZE)
    .fill(null)
    .map(() => Array(BOARD_SIZE).fill(null));

  let movedTilesCount = 0;

  for (let c = 0; c < BOARD_SIZE; c++) {
    let writeRow = BOARD_SIZE - 1;
    // Iterate from bottom to top
    for (let r = BOARD_SIZE - 1; r >= 0; r--) {
      const tile = grid[r][c];
      if (tile) {
        if (writeRow !== r) {
          movedTilesCount++;
        }
        newGrid[writeRow][c] = {
          ...tile,
          row: writeRow,
          col: c,
          isFalling: writeRow !== r,
        };
        writeRow--;
      }
    }
  }

  return { newGrid, movedTilesCount };
}

// Fill empty slots (at top of columns) with new tiles
export function fillEmptyTiles(grid: (Tile | null)[][]): (Tile | null)[][] {
  const newGrid = cloneGrid(grid);

  for (let c = 0; c < BOARD_SIZE; c++) {
    for (let r = 0; r < BOARD_SIZE; r++) {
      if (!newGrid[r][c]) {
        const type = getRandomElementType();
        newGrid[r][c] = createTile(type, r, c, true);
      }
    }
  }

  return newGrid;
}

// Remove matched tiles from grid
export function clearMatchedTiles(
  grid: (Tile | null)[][],
  positions: Position[]
): (Tile | null)[][] {
  const newGrid = cloneGrid(grid);
  for (const pos of positions) {
    newGrid[pos.row][pos.col] = null;
  }
  return newGrid;
}

// Create initial quests for a given level
export function createQuestsForLevel(level: number): Quest[] {
  // Level scaling:
  // Quest 1: Score target (100 for level 1, +150 per level)
  // Quest 2: Collect red elements (10 for level 1, +3 per level)
  // Quest 3: 4-match combo (1 combo of 4 elements)
  const scoreTarget = 100 + (level - 1) * 150;
  const redTarget = 10 + (level - 1) * 3;

  return [
    {
      id: `quest_score_lvl_${level}`,
      type: 'score',
      title: `Набрать ${scoreTarget} очков`,
      description: `Заработайте ${scoreTarget} очков на этом уровне`,
      current: 0,
      target: scoreTarget,
      completed: false,
      rewardText: '+3 хода',
      rewardType: 'moves',
    },
    {
      id: `quest_red_lvl_${level}`,
      type: 'red_hearts',
      title: `Собрать ${redTarget} сердец`,
      description: `Уничтожьте ${redTarget} красных сердец`,
      current: 0,
      target: redTarget,
      completed: false,
      rewardText: '+1 молоток',
      rewardType: 'booster_hammer',
    },
    {
      id: `quest_combo_lvl_${level}`,
      type: 'combo4',
      title: 'Комбинация из 4',
      description: 'Соберите 1 ряд из 4 или более элементов',
      current: 0,
      target: 1,
      completed: false,
      rewardText: '+1 молния',
      rewardType: 'booster_lightning',
    },
  ];
}

// Get moves allowed for level (gradually decreases as requested: "На каждом новом уровне уменьшай количество доступных ходов")
export function getMovesForLevel(level: number): number {
  // Level 1: 30 moves, Level 2: 27, Level 3: 25, Level 4: 23, min 18 moves
  return Math.max(18, 30 - (level - 1) * 2);
}
