/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import confetti from 'canvas-confetti';
import {
  Tile,
  Position,
  GameStats,
  BoosterState,
  BoosterType,
  Quest,
  GameStatus,
} from './types/game';
import {
  BOARD_SIZE,
  createInitialBoard,
  cloneGrid,
  findMatches,
  calculateMatchScore,
  clearMatchedTiles,
  applyGravity,
  fillEmptyTiles,
  hasPossibleMoves,
  shuffleBoard,
  createQuestsForLevel,
  getMovesForLevel,
  areAdjacent,
} from './utils/match3Logic';
import { soundManager } from './utils/audio';
import { HeaderHUD } from './components/HeaderHUD';
import { GameBoard } from './components/GameBoard';
import { BoosterBar } from './components/BoosterBar';
import { QuestPanel } from './components/QuestPanel';
import { RulesModal } from './components/Modals/RulesModal';
import { GameOverModal } from './components/Modals/GameOverModal';
import { PauseModal } from './components/Modals/PauseModal';
import { BoosterConfirmModal } from './components/Modals/BoosterConfirmModal';
import { AndroidExportModal } from './components/Modals/AndroidExportModal';
import { DailyRewardModal } from './components/Modals/DailyRewardModal';
import {
  isDailyRewardAvailable,
  recordDailyRewardClaim,
  loadSavedBoosters,
  saveBoosters,
} from './utils/dailyReward';

export default function App() {
  // Theme state: dark deep-blue (default) or light candy
  const [isDark, setIsDark] = useState<boolean>(() => {
    const saved = localStorage.getItem('sweet_battle_theme');
    return saved !== null ? saved === 'dark' : true;
  });

  // Sound muted state
  const [isMuted, setIsMuted] = useState<boolean>(() => soundManager.getMuted());

  // Game Stats
  const [stats, setStats] = useState<GameStats>(() => {
    const savedHigh = localStorage.getItem('sweet_battle_highscore');
    return {
      score: 0,
      level: 1,
      movesLeft: getMovesForLevel(1),
      highScore: savedHigh ? parseInt(savedHigh, 10) : 0,
      combo: 0,
    };
  });

  // Game Board Grid
  const [grid, setGrid] = useState<(Tile | null)[][]>(() => createInitialBoard());

  // Board interaction states
  const [selectedPos, setSelectedPos] = useState<Position | null>(null);
  const [status, setStatus] = useState<GameStatus>('idle');
  const [isPaused, setIsPaused] = useState<boolean>(false);

  // Boosters State (persisted in localStorage)
  const [boosters, setBoosters] = useState<BoosterState>(() => loadSavedBoosters());
  const [activeBooster, setActiveBooster] = useState<BoosterType | null>(null);
  const [confirmingBooster, setConfirmingBooster] = useState<BoosterType | null>(null);

  // Daily Reward State
  const [dailyRewardOpen, setDailyRewardOpen] = useState<boolean>(false);
  const [hasDailyRewardAvailable, setHasDailyRewardAvailable] = useState<boolean>(() =>
    isDailyRewardAvailable()
  );

  // Level Quests
  const [quests, setQuests] = useState<Quest[]>(() => createQuestsForLevel(1));
  const [claimNotification, setClaimNotification] = useState<string | null>(null);

  // Visual Effects
  const [floatingText, setFloatingText] = useState<
    { id: string; text: string; row: number; col: number; color?: string }[]
  >([]);
  const [lightningRowIndex, setLightningRowIndex] = useState<number | null>(null);

  // Modals
  const [rulesOpen, setRulesOpen] = useState<boolean>(false);
  const [androidModalOpen, setAndroidModalOpen] = useState<boolean>(false);
  const [gameOverOpen, setGameOverOpen] = useState<boolean>(false);

  // Automatically open Daily Reward modal on first visit of the day
  useEffect(() => {
    if (isDailyRewardAvailable()) {
      const timer = setTimeout(() => {
        setDailyRewardOpen(true);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, []);

  // Save boosters to localStorage on any change
  useEffect(() => {
    saveBoosters(boosters);
  }, [boosters]);

  // Helper ref to avoid stale closures in timeouts
  const gridRef = useRef(grid);
  gridRef.current = grid;

  const statsRef = useRef(stats);
  statsRef.current = stats;

  const questsRef = useRef(quests);
  questsRef.current = quests;

  // Toggle Theme
  const handleToggleTheme = () => {
    setIsDark((prev) => {
      const next = !prev;
      localStorage.setItem('sweet_battle_theme', next ? 'dark' : 'light');
      return next;
    });
  };

  // Toggle Sound
  const handleToggleSound = () => {
    const nextMuted = soundManager.toggleMute();
    setIsMuted(nextMuted);
  };

  // Show floating text indicator on board
  const addFloatingText = (text: string, row: number, col: number, color?: string) => {
    const id = `ft_${Date.now()}_${Math.random()}`;
    setFloatingText((prev) => [...prev, { id, text, row, col, color }]);
    setTimeout(() => {
      setFloatingText((prev) => prev.filter((item) => item.id !== id));
    }, 900);
  };

  // Check and grant completed quests rewards
  const evaluateQuests = useCallback(
    (
      currentScore: number,
      collectedRedHearts: number,
      hasCombo4: boolean
    ) => {
      setQuests((prevQuests) => {
        let rewardTriggered = false;
        let rewardMessage = '';

        const nextQuests = prevQuests.map((q) => {
          if (q.completed) return q;

          let newCurrent = q.current;
          let completed = false;

          if (q.type === 'score') {
            newCurrent = Math.min(q.target, currentScore);
            completed = newCurrent >= q.target;
          } else if (q.type === 'red_hearts') {
            newCurrent = Math.min(q.target, q.current + collectedRedHearts);
            completed = newCurrent >= q.target;
          } else if (q.type === 'combo4') {
            if (hasCombo4) {
              newCurrent = 1;
              completed = true;
            }
          }

          if (completed && !q.completed) {
            rewardTriggered = true;
            rewardMessage = `Задание выполнено: ${q.title}! Награда: ${q.rewardText}`;

            // Grant rewards
            if (q.rewardType === 'moves') {
              setStats((s) => ({ ...s, movesLeft: s.movesLeft + 3 }));
            } else if (q.rewardType === 'booster_hammer') {
              setBoosters((b) => ({ ...b, hammer: b.hammer + 1 }));
            } else if (q.rewardType === 'booster_lightning') {
              setBoosters((b) => ({ ...b, lightning: b.lightning + 1 }));
            }
          }

          return {
            ...q,
            current: newCurrent,
            completed,
          };
        });

        if (rewardTriggered) {
          soundManager.playQuestComplete();
          try {
            confetti({
              particleCount: 40,
              spread: 60,
              origin: { y: 0.6 },
            });
          } catch {}
          setClaimNotification(rewardMessage);
          setTimeout(() => setClaimNotification(null), 3500);
        }

        return nextQuests;
      });
    },
    []
  );

  // Core cascade processing loop
  const processCascade = useCallback(
    async (initialGrid: (Tile | null)[][], comboCount: number = 1): Promise<void> => {
      setStatus('matching');

      const matches = findMatches(initialGrid);
      if (matches.matchedPositions.length === 0) {
        // Cascade finished: check moves and possible shuffles
        setStatus('idle');

        // Check if moves exhausted
        if (statsRef.current.movesLeft <= 0) {
          setStatus('game_over');
          setGameOverOpen(true);
          soundManager.playGameOver();
          return;
        }

        // Check if board has valid moves available
        if (!hasPossibleMoves(initialGrid)) {
          addFloatingText('Перемешивание!', 3, 3, 'text-purple-400');
          soundManager.playBoosterShuffle();
          const shuffled = shuffleBoard(initialGrid);
          setGrid(shuffled);
        }
        return;
      }

      // 1. Calculate Score
      const points = calculateMatchScore(matches.matchGroups, comboCount);
      const matchedTypes = matches.matchGroups.map((g) => g.type);
      soundManager.playMatchWithElements(matchedTypes, comboCount, matches.matchedPositions.length);

      // 2. Visual matched pop state
      const matchingGrid = cloneGrid(initialGrid);
      for (const pos of matches.matchedPositions) {
        if (matchingGrid[pos.row][pos.col]) {
          matchingGrid[pos.row][pos.col] = {
            ...matchingGrid[pos.row][pos.col]!,
            isMatched: true,
          };
        }
      }
      setGrid(matchingGrid);

      // Combo banner floating text
      const centerPos = matches.matchedPositions[0] || { row: 3, col: 3 };
      if (comboCount > 1) {
        addFloatingText(`Комбо x${comboCount}! +${points}`, centerPos.row, centerPos.col, 'text-amber-300');
      } else {
        addFloatingText(`+${points}`, centerPos.row, centerPos.col, 'text-amber-400');
      }

      // 3. Update stats & check Level Progression (every 500 points raises level)
      setStats((prev) => {
        const newScore = prev.score + points;
        const newHighScore = Math.max(newScore, prev.highScore);
        if (newHighScore > prev.highScore) {
          localStorage.setItem('sweet_battle_highscore', String(newHighScore));
        }

        const calculatedLevel = Math.floor(newScore / 500) + 1;
        if (calculatedLevel > prev.level) {
          // Level up celebration!
          soundManager.playLevelUp();
          try {
            confetti({
              particleCount: 80,
              spread: 90,
              origin: { y: 0.5 },
            });
          } catch {}
          // Bonus moves for next level
          const extraMoves = getMovesForLevel(calculatedLevel);
          // Set new quests for this level
          setQuests(createQuestsForLevel(calculatedLevel));
          addFloatingText(`УРОВЕНЬ ${calculatedLevel}!`, 2, 3, 'text-emerald-400 text-lg');

          return {
            ...prev,
            score: newScore,
            highScore: newHighScore,
            level: calculatedLevel,
            movesLeft: prev.movesLeft + extraMoves,
            combo: comboCount,
          };
        }

        return {
          ...prev,
          score: newScore,
          highScore: newHighScore,
          combo: comboCount,
        };
      });

      // 4. Update Quest Progress
      const redCount = matches.collectedCountByType['heart'] || 0;
      evaluateQuests(
        statsRef.current.score + points,
        redCount,
        matches.hasMatchOf4OrMore
      );

      // 5. Wait for pop animation
      await new Promise((res) => setTimeout(res, 220));

      // 6. Clear matched cells
      const clearedGrid = clearMatchedTiles(matchingGrid, matches.matchedPositions);
      setGrid(clearedGrid);

      // 7. Gravity fall
      setStatus('dropping');
      const { newGrid: fallenGrid } = applyGravity(clearedGrid);
      setGrid(fallenGrid);

      await new Promise((res) => setTimeout(res, 180));

      // 8. Fill top empty cells with new elements
      const replenishedGrid = fillEmptyTiles(fallenGrid);
      setGrid(replenishedGrid);

      await new Promise((res) => setTimeout(res, 220));

      // 9. Chain reaction next step
      await processCascade(replenishedGrid, comboCount + 1);
    },
    [evaluateQuests]
  );

  // Swap request handler
  const handleSwapRequest = async (p1: Position, p2: Position) => {
    if (status !== 'idle' || isPaused) return;
    if (!areAdjacent(p1, p2)) return;

    setStatus('swapping');
    setSelectedPos(null);

    // Swap tiles in temp grid
    const current = cloneGrid(gridRef.current);
    const t1 = current[p1.row][p1.col];
    const t2 = current[p2.row][p2.col];

    if (!t1 || !t2) {
      setStatus('idle');
      return;
    }

    soundManager.playSwap();

    current[p1.row][p1.col] = { ...t2, row: p1.row, col: p1.col };
    current[p2.row][p2.col] = { ...t1, row: p2.row, col: p2.col };
    setGrid(current);

    // Check if swap produces matches
    await new Promise((res) => setTimeout(res, 180));
    const matches = findMatches(current);

    if (matches.matchedPositions.length === 0) {
      // Revert swap
      soundManager.playInvalid();
      current[p1.row][p1.col] = { ...t1, row: p1.row, col: p1.col };
      current[p2.row][p2.col] = { ...t2, row: p2.row, col: p2.col };
      setGrid(current);

      await new Promise((res) => setTimeout(res, 160));
      setStatus('idle');
    } else {
      // Valid move! Deduct 1 move and start cascades
      setStats((prev) => ({ ...prev, movesLeft: Math.max(0, prev.movesLeft - 1) }));
      await processCascade(current, 1);
    }
  };

  // Booster selection click
  const handleSelectBooster = (type: BoosterType) => {
    if (status !== 'idle' || isPaused) return;
    if (boosters[type] <= 0) return;

    // Show confirmation modal as required
    setConfirmingBooster(type);
  };

  // Confirm booster usage
  const handleConfirmBooster = () => {
    if (!confirmingBooster) return;
    const booster = confirmingBooster;
    setConfirmingBooster(null);

    if (booster === 'shuffle') {
      // Immediate execution
      setBoosters((b) => ({ ...b, shuffle: b.shuffle - 1 }));
      soundManager.playBoosterShuffle();
      addFloatingText('Поле перемешано!', 3, 3, 'text-purple-400');
      const shuffled = shuffleBoard(gridRef.current);
      setGrid(shuffled);
    } else {
      // Enter targeting mode
      setActiveBooster(booster);
    }
  };

  // Execute targeted booster on board
  const handleBoosterTarget = async (pos: Position) => {
    if (!activeBooster || status !== 'idle') return;

    if (activeBooster === 'hammer') {
      const targetTile = gridRef.current[pos.row]?.[pos.col];
      // Consume 1 hammer
      setBoosters((b) => ({ ...b, hammer: Math.max(0, b.hammer - 1) }));
      setActiveBooster(null);
      soundManager.playBoosterHammer();
      if (targetTile) {
        soundManager.playElementPop(targetTile.type, 1);
      }
      addFloatingText('Удар!', pos.row, pos.col, 'text-rose-400');

      // Clear targeted cell
      const newGrid = cloneGrid(gridRef.current);
      newGrid[pos.row][pos.col] = null;
      setGrid(newGrid);

      // Cascade drop
      setStatus('dropping');
      const { newGrid: fallenGrid } = applyGravity(newGrid);
      setGrid(fallenGrid);
      await new Promise((res) => setTimeout(res, 200));

      const replenished = fillEmptyTiles(fallenGrid);
      setGrid(replenished);
      await new Promise((res) => setTimeout(res, 200));

      // Trigger cascade matches if any
      await processCascade(replenished, 1);
    } else if (activeBooster === 'lightning') {
      // Consume 1 lightning
      setBoosters((b) => ({ ...b, lightning: Math.max(0, b.lightning - 1) }));
      setActiveBooster(null);
      soundManager.playBoosterLightning();

      // Show electric beam animation across row
      setLightningRowIndex(pos.row);
      addFloatingText('Молния!', pos.row, 3, 'text-cyan-400 font-black');

      await new Promise((res) => setTimeout(res, 300));
      setLightningRowIndex(null);

      // Clear entire row
      const newGrid = cloneGrid(gridRef.current);
      for (let c = 0; c < BOARD_SIZE; c++) {
        newGrid[pos.row][c] = null;
      }
      setGrid(newGrid);

      // Points for destroyed row
      const rowPoints = 80;
      setStats((prev) => ({
        ...prev,
        score: prev.score + rowPoints,
        highScore: Math.max(prev.score + rowPoints, prev.highScore),
      }));

      // Cascade drop
      setStatus('dropping');
      const { newGrid: fallenGrid } = applyGravity(newGrid);
      setGrid(fallenGrid);
      await new Promise((res) => setTimeout(res, 200));

      const replenished = fillEmptyTiles(fallenGrid);
      setGrid(replenished);
      await new Promise((res) => setTimeout(res, 200));

      await processCascade(replenished, 1);
    }
  };

  // Claim Daily Reward handler
  const handleClaimDailyReward = (booster: BoosterType) => {
    const { newStreak } = recordDailyRewardClaim(booster);
    setHasDailyRewardAvailable(false);

    setBoosters((prev) => {
      const updated = {
        ...prev,
        [booster]: prev[booster] + 1,
      };
      saveBoosters(updated);
      return updated;
    });

    const boosterNames: Record<BoosterType, string> = {
      hammer: 'Молоток',
      lightning: 'Молния',
      shuffle: 'Перемешивание',
    };

    setClaimNotification(
      `Ежедневная награда получена: +1 ${boosterNames[booster]}! (Серия: ${newStreak} дн.)`
    );
    setTimeout(() => setClaimNotification(null), 4000);
  };

  // Restart Game
  const handleRestart = () => {
    const newBoard = createInitialBoard();
    const moves = getMovesForLevel(1);
    setGrid(newBoard);
    setSelectedPos(null);
    setStatus('idle');
    setIsPaused(false);
    setActiveBooster(null);
    setConfirmingBooster(null);
    setGameOverOpen(false);
    setLightningRowIndex(null);
    setQuests(createQuestsForLevel(1));
    // Keep accumulated/saved boosters or ensure minimum default
    setBoosters((prev) => ({
      hammer: Math.max(3, prev.hammer),
      lightning: Math.max(2, prev.lightning),
      shuffle: Math.max(2, prev.shuffle),
    }));
    setStats((prev) => ({
      score: 0,
      level: 1,
      movesLeft: moves,
      highScore: prev.highScore,
      combo: 0,
    }));
  };

  return (
    <div
      className={`min-h-screen w-full transition-colors duration-500 overflow-x-hidden ${
        isDark
          ? 'bg-gradient-to-b from-slate-950 via-slate-900 to-indigo-950 text-slate-100'
          : 'bg-gradient-to-b from-sky-100 via-indigo-50 to-pink-50 text-slate-900'
      }`}
    >
      {/* Background ambient glow shapes */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div
          className={`absolute -top-40 -left-40 w-96 h-96 rounded-full blur-3xl opacity-30 ${
            isDark ? 'bg-indigo-600' : 'bg-pink-300'
          }`}
        />
        <div
          className={`absolute top-1/2 -right-40 w-96 h-96 rounded-full blur-3xl opacity-25 ${
            isDark ? 'bg-cyan-600' : 'bg-sky-300'
          }`}
        />
        <div
          className={`absolute -bottom-40 left-1/3 w-96 h-96 rounded-full blur-3xl opacity-20 ${
            isDark ? 'bg-purple-600' : 'bg-amber-300'
          }`}
        />
      </div>

      {/* Main Container */}
      <div className="relative z-10 w-full max-w-xl mx-auto px-3 sm:px-4 py-3 sm:py-5 flex flex-col gap-3 min-h-screen justify-between">
        {/* Top Header HUD */}
        <HeaderHUD
          stats={stats}
          isPaused={isPaused}
          isMuted={isMuted}
          isDark={isDark}
          isDailyRewardAvailable={hasDailyRewardAvailable}
          onOpenDailyReward={() => setDailyRewardOpen(true)}
          onTogglePause={() => setIsPaused((p) => !p)}
          onToggleSound={handleToggleSound}
          onToggleTheme={handleToggleTheme}
          onRestart={handleRestart}
          onOpenRules={() => setRulesOpen(true)}
          onOpenAndroidModal={() => setAndroidModalOpen(true)}
        />

        {/* Level Quests Panel */}
        <QuestPanel
          quests={quests}
          isDark={isDark}
          onClaimNotification={claimNotification}
        />

        {/* Game Board */}
        <div className="relative flex-1 flex items-center justify-center my-1">
          <GameBoard
            grid={grid}
            selectedPos={selectedPos}
            onTileSelect={(pos) => setSelectedPos((prev) => (prev?.row === pos.row && prev?.col === pos.col ? null : pos))}
            onSwapRequest={handleSwapRequest}
            activeBooster={activeBooster}
            onBoosterTarget={handleBoosterTarget}
            status={isPaused ? 'paused' : status}
            isDark={isDark}
            floatingText={floatingText}
            lightningRowIndex={lightningRowIndex}
          />

          {/* Pause Overlay on Board */}
          {isPaused && (
            <div className="absolute inset-0 z-30 rounded-3xl backdrop-blur-md bg-slate-950/40 flex items-center justify-center">
              <div className="text-center p-4">
                <span className="text-lg font-black text-amber-400">Пауза</span>
                <p className="text-xs text-slate-300 mt-1">Нажмите кнопку продолжения сверху</p>
              </div>
            </div>
          )}
        </div>

        {/* Boosters Row */}
        <BoosterBar
          boosters={boosters}
          activeBooster={activeBooster}
          onSelectBooster={handleSelectBooster}
          onCancelBooster={() => setActiveBooster(null)}
          disabled={status !== 'idle' || isPaused}
          isDark={isDark}
        />

        {/* Quiet footer */}
        <footer className="text-center text-[10px] text-slate-400 py-1">
          Сладкая битва · Логическая головоломка «Три в ряд»
        </footer>
      </div>

      {/* Modals */}
      <RulesModal
        isOpen={rulesOpen}
        onClose={() => setRulesOpen(false)}
        isDark={isDark}
      />

      <PauseModal
        isOpen={isPaused}
        isDark={isDark}
        onResume={() => setIsPaused(false)}
        onRestart={handleRestart}
        onOpenRules={() => {
          setIsPaused(false);
          setRulesOpen(true);
        }}
      />

      <GameOverModal
        isOpen={gameOverOpen}
        stats={stats}
        quests={quests}
        isDark={isDark}
        onPlayAgain={handleRestart}
        onMainMenu={() => {
          handleRestart();
          setRulesOpen(true);
        }}
      />

      <BoosterConfirmModal
        booster={confirmingBooster}
        isOpen={confirmingBooster !== null}
        isDark={isDark}
        onConfirm={handleConfirmBooster}
        onCancel={() => setConfirmingBooster(null)}
      />

      <AndroidExportModal
        isOpen={androidModalOpen}
        onClose={() => setAndroidModalOpen(false)}
        isDark={isDark}
      />

      <DailyRewardModal
        isOpen={dailyRewardOpen}
        isDark={isDark}
        isRewardAvailable={hasDailyRewardAvailable}
        onClaim={handleClaimDailyReward}
        onClose={() => setDailyRewardOpen(false)}
      />
    </div>
  );
}
